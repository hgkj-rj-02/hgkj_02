/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : travel

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 07/07/2019 17:59:54
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for car
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car`  (
  `carID` int(11) NOT NULL AUTO_INCREMENT,
  `customerID` int(11) NOT NULL,
  `lineID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `time` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`carID`) USING BTREE,
  INDEX `FK_Car_Customer`(`customerID`) USING BTREE,
  INDEX `FK_Car_Line`(`lineID`) USING BTREE,
  CONSTRAINT `FK_Car_Customer` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_Car_Line` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of car
-- ----------------------------
INSERT INTO `car` VALUES (10, 8, 'europe3', '2019-07-05');
INSERT INTO `car` VALUES (11, 8, 'hongkong', '2019-07-05');
INSERT INTO `car` VALUES (14, 1, 'yurhf1', '2019-07-05');
INSERT INTO `car` VALUES (15, 1, 'hongkong', '2019-07-05');
INSERT INTO `car` VALUES (16, 10, 'ghgjj6', '2019-07-06');
INSERT INTO `car` VALUES (17, 10, 'hongkong', '2019-07-06');
INSERT INTO `car` VALUES (19, 8, 'sanya', '2019-07-07');
INSERT INTO `car` VALUES (20, 1, 'ghgjj6', '2019-07-07');

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer`  (
  `customerID` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(6) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `gender` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `identityId` varchar(18) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tel` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `type` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`customerID`) USING BTREE,
  UNIQUE INDEX `account`(`account`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES (1, '123456', '张三', '123456', '男', '123456789012345678', '12345678901', 0);
INSERT INTO `customer` VALUES (2, '758457', 'jack', 'jack', '男', '123132132123132132', '13212131554', 1);
INSERT INTO `customer` VALUES (3, '3435', 'wzn', 'wzn', '男', '362324200011015619', '13479333255', 1);
INSERT INTO `customer` VALUES (8, '787879', 'rose', '123456', '女', '123434545657893452', '13237890345', 0);
INSERT INTO `customer` VALUES (9, '578679', '李四', '123456', '男', '123434545657897654', '13237897894', 0);
INSERT INTO `customer` VALUES (10, '55555', 'Luce', '123456', '女', '123434545657898765', '15437897894', NULL);

-- ----------------------------
-- Table structure for line
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line`  (
  `lineID` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineTypeID` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineName` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `days` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `vehicle` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `introduction` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `reason` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `arrange` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `price` decimal(10, 2) NULL DEFAULT NULL,
  `teamBuy` int(11) NULL DEFAULT NULL,
  `teamBuyPrice` decimal(10, 2) NULL DEFAULT NULL,
  `beginTime` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `endTime` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `onTime` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`lineID`) USING BTREE,
  INDEX `FK_Line_LineType`(`lineTypeID`) USING BTREE,
  CONSTRAINT `FK_Line_LineType` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('beiJing', 'adddf3', '北京', '7', '飞机', '', '', '', 10980.00, NULL, NULL, NULL, NULL, '2019-07-01');
INSERT INTO `line` VALUES ('europe2', 'aaaa1', '希腊7日游', '7', '飞机', '希腊被誉为是西方文明的发源地...', '', '', 12390.00, 1, 7978.00, '2019-07-01', '2019-07-12', '2019-07-02');
INSERT INTO `line` VALUES ('europe3', 'aaaa1', '法国5日游', '5', '飞机', '在花都巴黎感受万种风情...', '', '', 9990.00, 1, 7980.00, '2019-06-25', '2019-06-29', '2019-07-02');
INSERT INTO `line` VALUES ('europe4', 'aaaa1', '仰光7日游', '7', '飞机', '仰光，为缅甸最大城市也是仰光省...', '', '', 10980.00, 1, 6565.00, '2019-07-01', '2019-07-10', '2019-07-02');
INSERT INTO `line` VALUES ('fsdfs1', 'fgfdh1', '泰国游', '5', '轮船', '泰国的风土人情', '', '', 7890.00, 1, 6565.00, '2019-06-25', '2019-06-30', '2019-06-30');
INSERT INTO `line` VALUES ('ghgjj6', 'aaaa1', '神户游', '5', '飞机', '神户的神秘...', '', '', 10980.00, 1, 6565.00, '2019-06-25', '2019-06-30', '2019-07-01');
INSERT INTO `line` VALUES ('hongkong', 'fgfdh1', '香港', '7', '飞机', '', '', '', 12390.00, NULL, NULL, NULL, NULL, '2019-07-01');
INSERT INTO `line` VALUES ('sanya', 'adddf3', '三亚', '5', '高铁', '', '', '', 9990.00, 1, 7890.00, '2019-06-27', '2019-07-12', '2019-07-01');
INSERT INTO `line` VALUES ('yurhf1', 'adddf3', '凤凰古城', '5', '高铁', '', '', '', 9990.00, 1, 8880.00, '2019-06-29', '2019-07-10', '2019-07-01');

-- ----------------------------
-- Table structure for linetype
-- ----------------------------
DROP TABLE IF EXISTS `linetype`;
CREATE TABLE `linetype`  (
  `lineTypeID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `typeName` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `time` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`lineTypeID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of linetype
-- ----------------------------
INSERT INTO `linetype` VALUES ('aaaa1', '国外游', '2019-07-01', 'img/5.jpg');
INSERT INTO `linetype` VALUES ('adddf3', '国内游', '2019-07-01', 'img/18.jpg');
INSERT INTO `linetype` VALUES ('fgfdh1', '海岛游', '2019-07-01', 'img/2.jpg');
INSERT INTO `linetype` VALUES ('sdgfsd2', '自驾游', '2019-06-27', 'img/8.jpg');

-- ----------------------------
-- Table structure for orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail`  (
  `odID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `customerID` int(11) NOT NULL,
  `lineName` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `price` decimal(10, 2) NULL DEFAULT NULL,
  `orderDate` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `travelDate` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `total` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `lineID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `state` int(255) NULL DEFAULT NULL,
  PRIMARY KEY (`odID`) USING BTREE,
  INDEX `FK_OrderDetail_line`(`lineID`) USING BTREE,
  INDEX `Fk_OrderDetail_Customer`(`customerID`) USING BTREE,
  CONSTRAINT `FK_OrderDetail_line` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `Fk_OrderDetail_Customer` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of orderdetail
-- ----------------------------
INSERT INTO `orderdetail` VALUES ('adsdf1', 1, '欧洲7日游', 6789.00, '2019-06-25', '2019-06-29', '9998', 'fsdfs1', 0);

-- ----------------------------
-- Table structure for otdetail
-- ----------------------------
DROP TABLE IF EXISTS `otdetail`;
CREATE TABLE `otdetail`  (
  `otID` int(11) NOT NULL AUTO_INCREMENT,
  `odID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `touristID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`otID`) USING BTREE,
  INDEX `FK_OTDetail_Tourist`(`touristID`) USING BTREE,
  INDEX `FK_OTDetail_OrderDetail`(`odID`) USING BTREE,
  CONSTRAINT `FK_OTDetail_OrderDetail` FOREIGN KEY (`odID`) REFERENCES `orderdetail` (`odID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_OTDetail_Tourist` FOREIGN KEY (`touristID`) REFERENCES `tourist` (`touristID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of otdetail
-- ----------------------------
INSERT INTO `otdetail` VALUES (1, 'adsdf1', 'asdfg2');

-- ----------------------------
-- Table structure for picture
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture`  (
  `pictureID` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `lineID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`pictureID`) USING BTREE,
  INDEX `FK_Picture_Line`(`lineID`) USING BTREE,
  CONSTRAINT `FK_Picture_Line` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 35 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of picture
-- ----------------------------
INSERT INTO `picture` VALUES (3, '海边风景', 'img/19.jpg', 'hongkong');
INSERT INTO `picture` VALUES (4, '夜景', 'img/19.jpg', 'hongkong');
INSERT INTO `picture` VALUES (5, '迪士尼', 'img/17.jpg', 'hongkong');
INSERT INTO `picture` VALUES (6, '旺街', 'img/15.jpg', 'hongkong');
INSERT INTO `picture` VALUES (15, '祭坛', 'img/11.jpg', 'beiJing');
INSERT INTO `picture` VALUES (16, '天安门', 'img/9.jpg', 'beiJing');
INSERT INTO `picture` VALUES (17, '水立方', 'img/14.jpg', 'beiJing');
INSERT INTO `picture` VALUES (18, '长城', 'img/10.jpg', 'beiJing');
INSERT INTO `picture` VALUES (23, '海边风景', 'img/3.jpg', 'europe2');
INSERT INTO `picture` VALUES (24, '111', 'img/tj5.png', 'europe2');
INSERT INTO `picture` VALUES (25, '111', 'img/8.jpg', 'europe2');
INSERT INTO `picture` VALUES (26, 'aaaa', 'img/tj6.png', 'europe2');
INSERT INTO `picture` VALUES (27, '巴黎铁塔', 'img/6.jpg', 'europe3');
INSERT INTO `picture` VALUES (28, 'aaaa', 'img/5.jpg', 'europe3');
INSERT INTO `picture` VALUES (29, '666', 'img/2.jpg', 'europe3');
INSERT INTO `picture` VALUES (30, '海边风景', 'img/8.jpg', 'europe3');
INSERT INTO `picture` VALUES (31, '111', 'img/tj7.png', 'europe4');
INSERT INTO `picture` VALUES (32, '海边风景', 'img/tj4.png', 'europe4');
INSERT INTO `picture` VALUES (33, '6666', 'img/typeact1.jpg', 'europe4');
INSERT INTO `picture` VALUES (34, '2222', 'img/tj8.jpg', 'europe4');

-- ----------------------------
-- Table structure for tourist
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist`  (
  `touristID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `IDCard` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tel` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `realName` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`touristID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tourist
-- ----------------------------
INSERT INTO `tourist` VALUES ('aaaaa', '123434545657892387', '13237893478', 'lili');
INSERT INTO `tourist` VALUES ('asd21', '123434545657893452', '15672890345', 'sanme');
INSERT INTO `tourist` VALUES ('asdfg2', '987654321012345678', '09876543210', '李四');
INSERT INTO `tourist` VALUES ('ddddd', '123434587654393452', '13876900345', 'yunne');
INSERT INTO `tourist` VALUES ('dhgdh', '123434545657893452', '13237890345', 'rose');
INSERT INTO `tourist` VALUES ('dsgsffd', '123434545654393452', '13237890345', 'king');
INSERT INTO `tourist` VALUES ('hjuio', '521434545654393452', '13876900345', 'yuini');

SET FOREIGN_KEY_CHECKS = 1;
