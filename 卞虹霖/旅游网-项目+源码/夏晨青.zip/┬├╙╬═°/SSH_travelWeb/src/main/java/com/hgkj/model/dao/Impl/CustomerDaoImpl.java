package com.hgkj.model.dao.Impl;

import com.hgkj.model.dao.CustomerDao;
import com.hgkj.model.entity.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class CustomerDaoImpl implements CustomerDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public Customer adminLoginDao(Customer customer) {
//        boolean result=false;
        String hql="from Customer where name=:name and password=:password";
        customer=(Customer)getSession().createQuery(hql).setParameter("name",customer.getName()).setParameter("password",customer.getPassword()).uniqueResult();
        try {
            this.sessionFactory.getCurrentSession().save(customer);
//            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return customer;
//        return result;
    }

    @Override
    public List<Customer> allCustomer() {
        Query query=getSession().createQuery("from Customer where type!=1");
        return query.list();
    }

    @Override
    public boolean registCutomer(Customer customer) {
        boolean result=false;
        try {
            this.sessionFactory.getCurrentSession().save(customer);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public Customer getCustomer(int customerId) {
       Customer customer=null;
        try {
            customer=(Customer) this.sessionFactory.getCurrentSession().get(Customer.class,customerId);
        }catch (Exception e){
            e.printStackTrace();
        }
        return customer;
    }
}
