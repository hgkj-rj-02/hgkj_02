package com.hgkj.model.service;

import com.hgkj.model.entity.Line;

import java.util.List;

public interface LineService {
    /**
     * 获取总页数
     * @param pageSize
     * @return
     */
    public int getTotalPage(int pageSize);
    /**
     * 查询所有线路
     * @return
     */
    public List<Line> allLineService(int pageIndex,int pageSize);
    /**
     * 查询不同线路类型下的线路
     * @return
     */
    public List<Line> lineTypeService();
    /**
     * 查询不同线路类型下的线路
     * @return
     */
    public List<Line> lineTypeService1();
    /**
     * 查询不同线路类型下的线路
     * @return
     */
    public List<Line> lineTypeService2();

    /**
     * 查询所有团购线路
     * @return
     */
    public List<Line> teamLine(int pageIndex,int pageSize);
    /**
     * 添加线路
     * @param line
     * @return
     */
    public boolean addLineService(Line line);

    /**
     * 删除线路
     * @param lineId
     * @return
     */
    public boolean deleteLineService(String lineId);

    /**
     * 修改线路
     * @param line
     * @return
     */
    public boolean updateLineService(Line line);

    /**
     * 获取线路
     * @param lineId
     * @return
     */
    public Line getLineService(String lineId);
}
