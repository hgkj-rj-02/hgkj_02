package com.hgkj.model.dao;

import com.hgkj.model.entity.Customer;

public interface AdminDao {
    /**
     *
     * @param customer
     * @return 管理员登录
     */
    public boolean adminLoginDao(Customer customer);
}
