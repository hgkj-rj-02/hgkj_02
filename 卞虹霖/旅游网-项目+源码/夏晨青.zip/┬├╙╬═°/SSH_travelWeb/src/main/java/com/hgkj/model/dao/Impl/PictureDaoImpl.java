package com.hgkj.model.dao.Impl;

import com.hgkj.model.dao.PictureDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class PictureDaoImpl implements PictureDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Picture> allPicture() {
        Query query=getSession().createQuery("from Picture");
        return query.list();
    }

    @Override
    public boolean addPicture(Picture picture) {
        boolean result=false;
        try {
            this.sessionFactory.getCurrentSession().save(picture);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean deletePicture(int pictureId) {
        boolean result=false;
        Line line=getSession().get(Line.class,pictureId);
        try {
            this.sessionFactory.getCurrentSession().delete(line);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}
