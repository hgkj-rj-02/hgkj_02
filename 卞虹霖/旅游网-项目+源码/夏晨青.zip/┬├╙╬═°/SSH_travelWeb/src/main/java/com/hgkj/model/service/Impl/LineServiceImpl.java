package com.hgkj.model.service.Impl;

import com.hgkj.model.dao.LineDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.service.LineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LineServiceImpl implements LineService {
    @Autowired
    private LineDao lineDao;

    public void setLineDao(LineDao lineDao) {
        this.lineDao = lineDao;
    }

    @Override
    public List<Line> allLineService(int pageIndex,int pageSize) {
        return lineDao.allLine(pageIndex,pageSize);
    }

    @Override
    public List<Line> lineTypeService() {
        return lineDao.lineType();
    }

    @Override
    public List<Line> lineTypeService1() {
        return lineDao.lineType1();
    }

    @Override
    public List<Line> lineTypeService2() {
        return lineDao.lineType2();
    }

    @Override
    public int getTotalPage(int pageSize) {
        return lineDao.getTotalPage(pageSize);
    }

    @Override
    public List<Line> teamLine(int pageIndex,int pageSize) {
        return lineDao.teamLine(pageIndex,pageSize);
    }

    @Override
    public boolean addLineService(Line line) {
        return lineDao.addLine(line);
    }

    @Override
    public boolean deleteLineService(String lineId) {
        return lineDao.deleteLine(lineId);
    }

    @Override
    public boolean updateLineService(Line line) {
        return lineDao.updateLine(line);
    }

    @Override
    public Line getLineService(String lineId) {
        return lineDao.getLine(lineId);
    }
}
