package com.hgkj.model.dao.Impl;

import com.hgkj.model.dao.CarDao;
import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.entity.Line;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class CarDaoImpl implements CarDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Car> carList() {
        Query query=getSession().createQuery("from Car");
        return query.list();
    }

    @Override
    public List<Car> carList(int customerId) {
        String hql="from Car where customer.customerId=:customerId";
        Query query=getSession().createQuery(hql).setParameter("customerId",customerId);
        return query.list();
    }

    @Override
    public boolean addCar(Car car) {
        boolean result=false;
        try {
            car.setCustomer(getSession().get(Customer.class,car.getCustomer().getCustomerId()));
            car.setLine(getSession().get(Line.class,car.getLine().getLineId()));
            this.sessionFactory.getCurrentSession().save(car);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    @Override
    public Customer getCustomerId(int customerId){
       Customer customer=null;
        try {
            customer=(Customer) this.sessionFactory.getCurrentSession().get(Customer.class,customerId);
        }catch (Exception e){
            e.printStackTrace();
        }
        return customer;
    }

    @Override
    public Line getLine(String lineId) {
        Line line=null;
        try {
            line=(Line) this.sessionFactory.getCurrentSession().get(Line.class,lineId);
        }catch (Exception e){
            e.printStackTrace();
        }
        return line;
    }

    @Override
    public boolean deleteCar(int CarId) {
        boolean result=false;
        Car car=getSession().get(Car.class,CarId);
        try {
            this.sessionFactory.getCurrentSession().delete(car);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public Car getCarId(int carId) {
        Car car=null;
        try {
            car=(Car) this.sessionFactory.getCurrentSession().get(Car.class,carId);
        }catch (Exception e){
            e.printStackTrace();
        }
        return car;
    }
}
