package com.hgkj.model.service.Impl;

import com.hgkj.model.dao.CarDao;
import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.entity.Line;
import com.hgkj.model.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CarServiceImpl implements CarService {
    @Autowired
    private CarDao carDao;

    public void setCarDao(CarDao carDao) {
        this.carDao = carDao;
    }

    @Override
    public List<Car> carListService() {
        return carDao.carList();
    }

    @Override
    public List<Car> carListService(int customerId) {
        return carDao.carList(customerId);
    }

    @Override
    public boolean addCarService(Car car) {
        return carDao.addCar(car);
    }

    @Override
    public Customer getCustomerIdService(int customerId) {
        return carDao.getCustomerId(customerId);
    }

    @Override
    public Line getLineService(String lineId) {
        return carDao.getLine(lineId);
    }

    @Override
    public boolean deleteCarService(int carId) {
        return carDao.deleteCar(carId);
    }

    @Override
    public Car getCarIdService(int carId) {
        return carDao.getCarId(carId);
    }
}
