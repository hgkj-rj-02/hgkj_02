package com.hgkj.model.service;

import com.hgkj.model.entity.Orderdetail;

import java.util.List;

public interface OrderDetailService {
    /**
     * 查看所有订单详情
     * @return
     */
    public List<Orderdetail> allOrderdetailService();
    /**
     * 查看某个用户的订单详情
     * @return
     */
    public List<Orderdetail> allOrderdetailService(int customerId);

    /**
     * 添加订单的详情
     * @return
     */
    public boolean addOrderDetailService(Orderdetail orderdetail);

    /**
     * 删除某个订单的详情
     * @return
     */
    public boolean deleteOrderdetailService(String odId);
}
