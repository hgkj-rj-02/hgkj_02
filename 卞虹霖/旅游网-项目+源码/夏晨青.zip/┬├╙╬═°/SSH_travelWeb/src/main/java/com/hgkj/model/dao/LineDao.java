package com.hgkj.model.dao;

import com.hgkj.model.entity.Line;

import java.util.List;

public interface LineDao {
    /**
     * 获取总页数
     * @param pageSize
     * @return
     */
    public int getTotalPage(int pageSize);
    /**
     * 查询所有线路
     * @return
     */
    public List<Line> allLine(int pageIndex,int pageSize);

    /**
     * 查询不同线路类型下的线路
     * @return
     */
    public List<Line> lineType();

    /**
     * 查询不同线路类型下的线路
     * @return
     */
    public List<Line> lineType1();

    /**
     * 查询不同线路类型下的线路
     * @return
     */
    public List<Line> lineType2();

    /**
     * 查询所有团购线路
     * @return
     */
    public List<Line> teamLine(int pageIndex,int pageSize);

    /**
     * 添加线路
     * @param line
     * @return
     */
    public boolean addLine(Line line);

    /**
     * 删除线路
     * @param lineId
     * @return
     */
    public boolean deleteLine(String lineId);

    /**
     * 修改线路
     * @param line
     * @return
     */
    public boolean updateLine(Line line);

    /**
     * 获取线路
     * @param lineId
     * @return
     */
    public Line getLine(String lineId);
}
