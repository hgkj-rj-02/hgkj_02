package com.hgkj.model.service.Impl;

import com.hgkj.model.dao.PictureDao;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.PictureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class PictureServiceImpl implements PictureService {
    @Autowired
    private PictureDao pictureDao;

    public void setPictureDao(PictureDao pictureDao) {
        this.pictureDao = pictureDao;
    }

    @Override
    public List<Picture> allPictureService() {
        return pictureDao.allPicture();
    }

    @Override
    public boolean addPictureService(Picture picture) {
        return pictureDao.addPicture(picture);
    }

    @Override
    public boolean deletePictureService(int pictureId) {
        return pictureDao.deletePicture(pictureId);
    }
}
