package com.hgkj.model.service;

import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.entity.Line;

import java.util.List;

public interface CarService {
    /**
     * 查看购物车
     * @return
     */
    public List<Car> carListService();
    /**
     * 查看某个用户的购物车
     * @return
     */
    public List<Car> carListService(int customerId);

    /**
     * 添加购物记录
     * @return
     */
    public boolean addCarService(Car car);
    /**
     * 获得客户
     * @param customerId
     * @return
     */
    public Customer getCustomerIdService(int customerId);
    /**
     * 获取线路
     * @param lineId
     * @return
     */
    public Line getLineService(String lineId);

    /**
     * 删除购物记录
     * @return
     */
    public boolean deleteCarService(int carId);

    /**
     * 查看单个购物
     * @param carId
     * @return
     */
    public Car getCarIdService(int carId);
}
