package com.hgkj.model.service.Impl;

import com.hgkj.model.dao.OrderDao;
import com.hgkj.model.entity.Otdetail;
import com.hgkj.model.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderDao orderDao;

    public void setOrderDao(OrderDao orderDao) {
        this.orderDao = orderDao;
    }

    @Override
    public List<Otdetail> allOrderService() {
        return orderDao.allOrder();
    }

    @Override
    public boolean addOrderService(Otdetail otdetail) {
        return orderDao.addOrder(otdetail);
    }

    @Override
    public boolean deleteOrderService(int otId) {
        return orderDao.deleteOrder(otId);
    }

    @Override
    public Otdetail getOtIdService(int otId) {
        return orderDao.getOtId(otId);
    }
}
