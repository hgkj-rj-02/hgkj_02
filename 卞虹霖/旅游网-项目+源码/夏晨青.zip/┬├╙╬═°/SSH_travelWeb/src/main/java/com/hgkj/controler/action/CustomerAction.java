package com.hgkj.controler.action;

import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CustomerService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpServletRequest;
import java.util.List;


@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class CustomerAction {
    private Customer customer;
    private HttpServletRequest request;

    public HttpServletRequest getRequest() {
        return request;
    }

    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }

    @Autowired
    private CustomerService customerService;

    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }
         //用户登录
    @Action(value = "customerLoginAction",results = {@Result(name = "login",type = "redirect",location = "qt/index.jsp"),@Result(name = "error",type = "redirect",location = "qt/login.jsp")})
    public String customerLogin(){
        customer=customerService.adminLoginDao(customer);
        if(customer!=null){
            ActionContext.getContext().getSession().put("customer",customer);
            return "login";
        }else{
            return "error";
        }
    }
    //用户退出登录
    @Action(value = "customerExitAction",results = {@Result(name = "exit",type = "redirect",location = "qt/login.jsp")})
    public String customerExit(){
//      request.getSession().invalidate();
        return "exit";
    }
//    @Action(value = "allCustomerAction",results = {@Result(name = "all",type = "redirect",location = "qt/index.jsp")})
//    public String allCustomer(){
//        List<Customer> customerList=customerService.allCustomer();
//        ActionContext.getContext().getSession().put("customerList",customerList);
//        return "all";
//    }
//    @Action(value = "findCustomerAction",results = {@Result(name = "find",type = "redirect",location = "qt/cart.jsp")})
//    public String findCustomer(){
//        customer=customerService.getCustomerService(customer.getCustomerId());
//        ActionContext.getContext().getSession().put("customer",customer);
//        return "find";
//    }
            //用户注册
    @Action(value = "registerCustomerAction",results = {@Result(name = "register",type = "redirect",location = "qt/login.jsp"),@Result(name = "error",type = "redirect",location = "qt/regist.jsp")})
    public String registerCustomer(){
        boolean result=customerService.registCutomer(customer);
        if(result){
            return "register";
        }else{
            return "error";
        }
//        List<Customer> customerList=customerService.allCustomer();
//        ActionContext.getContext().getSession().put("customerList",customerList);

    }
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
