package com.hgkj.model.dao.Impl;

import com.hgkj.model.dao.AdminDao;
import com.hgkj.model.entity.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository
@Transactional
public class AdminDaoImpl implements AdminDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public boolean adminLoginDao(Customer customer) {
        boolean result=false;
        String hql="from Customer where name=:name and password=:password and type=1";
        customer=(Customer)getSession().createQuery(hql).setParameter("name",customer.getName()).setParameter("password",customer.getPassword()).uniqueResult();
        try {
            this.sessionFactory.getCurrentSession().save(customer);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}
