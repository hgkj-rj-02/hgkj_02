package com.hgkj.model.dao;

import com.hgkj.model.entity.Picture;

import java.util.List;

public interface PictureDao {
    /**
     * 查询所有线路
     * @return
     */
    public List<Picture> allPicture();

    /**
     * 添加线路
     * @param picture
     * @return
     */
    public boolean addPicture(Picture picture);

    /**
     * 删除线路
     * @param pictureId
     * @return
     */
    public boolean deletePicture(int pictureId);
}
