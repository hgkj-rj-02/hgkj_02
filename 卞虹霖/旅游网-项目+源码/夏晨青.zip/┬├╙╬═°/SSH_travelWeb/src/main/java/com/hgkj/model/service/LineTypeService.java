package com.hgkj.model.service;

import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LineTypeService {
    /**
     * 查询所有线路类型
     * @return
     */
    public List<Linetype> allLineTypeService();

    /**
     * 添加线路类型
     * @param linetype
     * @return
     */
    public boolean addLineTypeService(Linetype linetype);

    /**
     * 删除线路类型
     * @param lineTypeID
     * @return
     */
    public boolean deleteLineTypeService(String lineTypeID);

    /**
     * 修改线路类型
     * @param linetype
     * @return
     */
    public boolean updateLineTypeService(Linetype linetype);

    /**
     * 获取线路类型
     * @param lineTypeID
     * @return
     */
    public Linetype getLineTypeService(String lineTypeID);
}
