package com.hgkj.model.entity;

public class Otdetail {
    private int otId;
    private Orderdetail orderdetail;
    private Tourist tourist;

    public void setTourist(Tourist tourist) {
        this.tourist = tourist;
    }

    public Tourist getTourist() {
        return tourist;
    }

    public int getOtId() {
        return otId;
    }

    public void setOtId(int otId) {
        this.otId = otId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Otdetail otdetail = (Otdetail) o;

        if (otId != otdetail.otId) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return otId;
    }

    public Orderdetail getOrderdetail() {
        return orderdetail;
    }

    public void setOrderdetail(Orderdetail orderdetail) {
        this.orderdetail = orderdetail;
    }
}
