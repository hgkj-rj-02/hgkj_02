package com.hgkj.model.service;

import com.hgkj.model.entity.Customer;

import java.util.List;

public interface CustomerService {
    /**
     *
     * @param customer
     * @return 管理员登录
     */
    public Customer adminLoginDao(Customer customer);

    /**
     * 查询所有用户
     * @return
     */
    public List<Customer> allCustomer();

    /**
     * 注册用户
     * @param customer
     * @return
     */
    public boolean registCutomer(Customer customer);
    /**
     * 查询某个用户
     * @param customerId
     * @return
     */
    public Customer getCustomerService(int customerId);
}
