package com.hgkj.controler.action;

import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.AdminService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class AdminAction {
    private Customer customer;
    private String message;
    private HttpServletRequest request;
    private HttpServletResponse response;
    @Autowired
    private AdminService adminService;

    public void setAdminService(AdminService adminService) {
        this.adminService = adminService;
    }
    //管理员登录
@Action(value = "adminLoginAction",results = {@Result(name = "login",type = "redirect",location = "ht/index.jsp"),@Result(name = "error",type="redirect",location = "ht/adminLogin.jsp")})
    public String adminLogin(){
    boolean result=adminService.adminLoginService(customer);
    if(result){
        ActionContext.getContext().getSession().put("customer",customer);
        return "login";
    }else{
       return "error";
    }
    }
    //管理员退出登录
    @Action(value = "exitAction",results = {@Result(name = "exit",type="redirect",location = "ht/adminLogin.jsp")})
    public String exit(){
//        HttpSession session= request.getSession();
//        session.invalidate();
        return "exit";
    }
    public HttpServletResponse getResponse() {
        return response;
    }

    public void setResponse(HttpServletResponse response) {
        this.response = response;
    }
    public HttpServletRequest getRequest() {
        return request;
    }

    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
