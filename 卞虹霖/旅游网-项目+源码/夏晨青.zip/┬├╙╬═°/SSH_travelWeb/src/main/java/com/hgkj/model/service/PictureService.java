package com.hgkj.model.service;

import com.hgkj.model.entity.Picture;

import java.util.List;

public interface PictureService {
    /**
     * 查询所有线路
     * @return
     */
    public List<Picture> allPictureService();

    /**
     * 添加线路
     * @param picture
     * @return
     */
    public boolean addPictureService(Picture picture);

    /**
     * 删除线路
     * @param pictureId
     * @return
     */
    public boolean deletePictureService(int pictureId);
}
