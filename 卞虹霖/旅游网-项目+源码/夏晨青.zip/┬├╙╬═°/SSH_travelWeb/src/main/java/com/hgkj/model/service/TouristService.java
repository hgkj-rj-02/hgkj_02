package com.hgkj.model.service;

import com.hgkj.model.entity.Tourist;

import java.util.List;

public interface TouristService {
    /**
     * 查询所有线路
     * @return
     */
    public List<Tourist> allTouristService();

    /**
     * 添加线路
     * @param tourist
     * @return
     */
    public boolean addTouristService(Tourist tourist);

    /**
     * 删除线路
     * @param touristId
     * @return
     */
    public boolean deleteTouristService(String touristId);

    /**
     * 修改线路
     * @param tourist
     * @return
     */
    public boolean updateTouristService(Tourist tourist);

    /**
     * 获取线路
     * @param touristId
     * @return
     */
    public Tourist getTouristService(String touristId);
}
