package com.hgkj.model.service.Impl;

import com.hgkj.model.dao.LineTypeDao;
import com.hgkj.model.entity.Linetype;
import com.hgkj.model.service.LineTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LineTypeServiceImpl implements LineTypeService {
    @Autowired
    private LineTypeDao lineTypeDao;

    public void setLineTypeDao(LineTypeDao lineTypeDao) {
        this.lineTypeDao = lineTypeDao;
    }

    @Override
    public List<Linetype> allLineTypeService() {
        return lineTypeDao.allLineType();
    }

    @Override
    public boolean addLineTypeService(Linetype linetype) {
        return lineTypeDao.addLineType(linetype);
    }

    @Override
    public boolean deleteLineTypeService(String lineTypeID) {
        return lineTypeDao.deleteLineType(lineTypeID);
    }

    @Override
    public boolean updateLineTypeService(Linetype linetype) {
        return lineTypeDao.updateLineType(linetype);
    }

    @Override
    public Linetype getLineTypeService(String lineTypeID) {
        return lineTypeDao.getLineType(lineTypeID);
    }
}
