package com.hgkj.model.service.Impl;

import com.hgkj.model.dao.OrderDetailDao;
import com.hgkj.model.entity.Orderdetail;
import com.hgkj.model.service.OrderDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderDetailServiceImpl implements OrderDetailService {
    @Autowired
    private OrderDetailDao orderDetailDao;

    public void setOrderDetailDao(OrderDetailDao orderDetailDao) {
        this.orderDetailDao = orderDetailDao;
    }

    @Override
    public List<Orderdetail> allOrderdetailService() {
        return orderDetailDao.allOrderdetail();
    }

    @Override
    public List<Orderdetail> allOrderdetailService(int customerId) {
        return orderDetailDao.allOrderdetail(customerId);
    }

    @Override
    public boolean addOrderDetailService(Orderdetail orderdetail) {
        return orderDetailDao.addOrderDetail(orderdetail);
    }

    @Override
    public boolean deleteOrderdetailService(String odId) {
        return orderDetailDao.deleteOrderdetail(odId);
    }
}
