package com.hgkj.controler.action;

import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.entity.Line;
import com.hgkj.model.service.CarService;
import com.hgkj.model.service.LineService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class CarAction {
    private Car car;
    private Line line;
    private Customer customer;
    @Autowired
    private CarService carService;

    public void setCarService(CarService carService) {
        this.carService = carService;
    }

//    @Action(value = "allCarShowAction", results = {@Result(name = "all", type = "redirect", location = "qt/cart.jsp")})
//    public String allCarShow() {
//        List<Car> carList = carService.carListService();
//        ActionContext.getContext().getSession().put("carList", carList);
//        return "all";
//    }
    //该用户的购物车展示
    @Action(value = "CarShowAction", results = {@Result(name = "all", type = "redirect", location = "qt/cart.jsp")})
    public String CarShow() {
        customer=(Customer) ActionContext.getContext().getSession().get("customer");
        List<Car> carList = carService.carListService(customer.getCustomerId());
        ActionContext.getContext().getSession().put("carList", carList);
        return "all";
    }
    //添加购物车
    @Action(value = "addCarAction",results = {@Result(name = "add",type = "redirectAction",params = {"actionName","CarShowAction"})})
    public String addCar(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        car.setTime(sdf.format(new Date()));
        carService.addCarService(car);
        return "add";
    }
    //删除购物车
    @Action(value = "deleteCarAction",results = {@Result(name = "delete",type = "redirectAction",params = {"actionName","CarShowAction"})})
    public String deleteCar(){
        carService.deleteCarService(car.getCarId());
        return "delete";
    }
   //下单
    @Action(value = "findOrderLineAction",results = {@Result(name = "find",type = "redirect",location = "qt/order.jsp")})
    public String findLine(){
        car=carService.getCarIdService(car.getCarId());
        ActionContext.getContext().getSession().put("car",car);
        return "find";
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }
}
