package com.hgkj.model.dao;

import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LineTypeDao {
    /**
     * 查询所有线路类型
     * @return
     */
   public List<Linetype> allLineType();

    /**
     * 添加线路类型
     * @param linetype
     * @return
     */
   public boolean addLineType(Linetype linetype);

    /**
     * 删除线路类型
     * @param lineTypeID
     * @return
     */
   public boolean deleteLineType(String lineTypeID);

    /**
     * 修改线路类型
     * @param linetype
     * @return
     */
   public boolean updateLineType(Linetype linetype);

    /**
     * 获取线路类型
     * @param lineTypeID
     * @return
     */
   public Linetype getLineType(String lineTypeID);
}
