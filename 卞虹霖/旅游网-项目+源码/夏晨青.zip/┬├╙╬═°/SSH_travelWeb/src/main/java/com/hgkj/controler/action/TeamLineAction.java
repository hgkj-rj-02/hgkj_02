package com.hgkj.controler.action;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Linetype;
import com.hgkj.model.service.LineService;
import com.hgkj.model.service.LineTypeService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class TeamLineAction {
    private Line line;
    private int pageIndex;
    private int pageSize=2;
    private String message;
    @Autowired
    private LineTypeService lineTypeService;

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }
    @Autowired
    private LineService lineService;

    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }
     //查看团购信息
    @Action(value = "allTeamBuyLineAction", results = {@Result(name = "all", type = "redirect", location = "ht/seeTeamBuyLine.jsp")})
    public String allTeamBuyLine() {
        //分页
        int totalPages = lineService.getTotalPage(pageSize);
        if (pageIndex < 1) {
            pageIndex=1;
        }else if (pageIndex> totalPages) {
            pageIndex = totalPages;
        }
        ActionContext.getContext().getSession().put("pageIndex",pageIndex);
        ActionContext.getContext().getSession().put("totalPages",totalPages);
        List<Line> allTeamLineList = lineService.teamLine(pageIndex,pageSize);
        ActionContext.getContext().getSession().put("allTeamLineList", allTeamLineList);
        return "all";
    }
    //修改团购信息
    @Action(value = "updateTeamLineAction", results = {@Result(name = "updateTeam", type = "redirectAction",params = {"actionName","allTeamBuyLineAction"})})
    public String updateTeamLineBuyType() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        line.setOnTime(sdf.format(new Date()));
        lineService.updateLineService(line);
        return "updateTeam";
    }
    @Action(value = "findTeamBuyLineAction",results = {@Result(name = "findTeam",type = "redirect",location = "ht/setTeamBuyLine.jsp")})
    public String findBuyLine(){
        line = lineService.getLineService(line.getLineId());
        List<Linetype> allLineTypeList = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("allLineTypeList", allLineTypeList);
        ActionContext.getContext().getSession().put("line", line);
        return "findTeam";
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
