package com.hgkj.model.service.Impl;

import com.hgkj.model.dao.AdminDao;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AdminDao adminDao;

    public void setAdminDao(AdminDao adminDao) {
        this.adminDao = adminDao;
    }

    @Override
    public boolean adminLoginService(Customer customer) {
        return adminDao.adminLoginDao(customer);
    }
}
