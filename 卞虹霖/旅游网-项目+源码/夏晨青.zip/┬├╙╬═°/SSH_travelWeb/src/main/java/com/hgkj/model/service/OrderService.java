package com.hgkj.model.service;

import com.hgkj.model.entity.Otdetail;

import java.util.List;

public interface OrderService {
    /**
     * 查看所有订单详情
     * @return
     */
    public List<Otdetail> allOrderService();

    /**
     * 添加订单的详情
     * @return
     */
    public boolean addOrderService(Otdetail otdetail);

    /**
     * 删除某个订单的详情
     * @return
     */
    public boolean deleteOrderService(int otId);
    /**
     * 获取某个游客订单
     * @param otId
     * @return
     */
    public Otdetail getOtIdService(int otId);
}
