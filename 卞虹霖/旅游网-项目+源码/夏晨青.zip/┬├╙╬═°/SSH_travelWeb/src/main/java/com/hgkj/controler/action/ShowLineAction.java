package com.hgkj.controler.action;

import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Line;
import com.hgkj.model.service.CarService;
import com.hgkj.model.service.LineService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class ShowLineAction {
    private int pageSize=6;
    private int pageIndex;
    private Line line;
    private Car car;
    @Autowired
    private LineService lineService;

    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }

    @Autowired
    private CarService carService;

    public void setCarService(CarService carService) {
        this.carService = carService;
    }
    @Action(value = "showLineAction", results = {@Result(name = "allLine", type = "redirect", location = "qt/index.jsp")})
    public String showLine() {
        List<Line> allLine1 = lineService.lineTypeService();
        ActionContext.getContext().getSession().put("allLine1", allLine1);
        return "allLine";
    }
    @Action(value = "showLineAction1",results = {@Result(name = "allLine1",type = "redirect", location = "qt/index.jsp")})
    public String showLine1(){
        List<Line> allLine2=lineService.lineTypeService1();
        ActionContext.getContext().getSession().put("allLine2", allLine2);
        return "allLine1";
    }
    @Action(value = "showLineAction2",results = {@Result(name = "allLine2",type = "redirect", location = "qt/index.jsp")})
    public String showLine2(){
        List<Line> allLine3=lineService.lineTypeService2();
        ActionContext.getContext().getSession().put("allLine3", allLine3);
        return "allLine2";
    }
    @Action(value = "findAction",results = {@Result(name = "find",type = "redirect",location = "qt/detail.jsp")})
   public String findLine(){
       line = lineService.getLineService(line.getLineId());
       ActionContext.getContext().getSession().put("line", line);
       return "find";
   }
//   @Action(value = "goCarAction",results = {@Result(name = "go",type = "redirect",location = "qt/addCar.jsp")})
//   public String goCar(){
//       car=carService.getCarIdService(car.getCarId());
//       ActionContext.getContext().getSession().put("car",car);
////       line = lineService.getLineService(line.getLineId());
////       ActionContext.getContext().getSession().put("line", line);
//        return "go";
//   }
   //查看团购
@Action(value = "showGroupBuyAction",results = {@Result(name = "allGroup",type = "redirect",location = "qt/group.jsp")})
   public String showGroupBuy(){
        //分页
    int totalPages = lineService.getTotalPage(pageSize);
    if (pageIndex < 1) {
        pageIndex=1;
    }else if (pageIndex> totalPages) {
        pageIndex = totalPages;
    }
    ActionContext.getContext().getSession().put("pageIndex",pageIndex);
    ActionContext.getContext().getSession().put("totalPages",totalPages);
    List<Line> allTeamLineList = lineService.teamLine(pageIndex,pageSize);
    ActionContext.getContext().getSession().put("allTeamLineList", allTeamLineList);
       return "allGroup";
   }
   @Action(value = "findGroupAction",results = {@Result(name = "group",type = "redirect",location = "qt/detail.jsp")})
   public String findGroup(){
       line = lineService.getLineService(line.getLineId());
       ActionContext.getContext().getSession().put("line", line);
        return "group";
   }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }
}
