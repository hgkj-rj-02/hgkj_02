package com.hgkj.controler.action;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Linetype;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.LineService;
import com.hgkj.model.service.LineTypeService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LineAction {
    private int pageSize=2;
    private int pageIndex;
    private Line line;
    private String message;
    private int[] pictureId;
    private File[] file;
    private String[] fileContentType;
    private String[] fileFileName;
    private String[] introduction;
    @Autowired
    private LineTypeService lineTypeService;

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }
    @Autowired
    private LineService lineService;

    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }
      //查看路线
    @Action(value = "allLineAction", results = {@Result(name = "all", type = "redirect", location = "ht/seeLine.jsp")})
    public String allLine() {
        //分页
        int totalPages = lineService.getTotalPage(pageSize);
        if (pageIndex < 1) {
            pageIndex=1;
        }else if (pageIndex> totalPages) {
            pageIndex = totalPages;
        }
        ActionContext.getContext().getSession().put("pageIndex",pageIndex);
        ActionContext.getContext().getSession().put("totalPages",totalPages);
        List<Line> allLineList = lineService.allLineService(pageIndex,pageSize);
        ActionContext.getContext().getSession().put("allLineList", allLineList);
        return "all";
    }
     //路线添加
    @Action(value = "addLineAction", results = {@Result(name = "add", type = "redirectAction", params = {"actionName", "allLineAction"})})
    public String addLine() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        line.setOnTime(sdf.format(new Date()));
        //图片上传
        for(int i=0;i<file.length;i++){
           String  path=ServletActionContext.getServletContext().getRealPath("img/"+fileFileName[i]);
           File dest=new File(path);
            try {
                FileUtils.copyFile(file[i], dest);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Picture picture=new Picture();
            picture.setName("img/"+fileFileName[i]);
            picture.setIntroduction(introduction[i]);
            picture.setLine(line);
            line.getPictureSet().add(picture);
        }
        lineService.addLineService(line);
        return "add";
    }
    //删除线路
    @Action(value = "deleteLineAction",results = {@Result(name = "delete",type = "redirectAction", params = {"actionName", "allLineAction"})})
    public String deleteLine() {
        lineService.deleteLineService(line.getLineId());
//        List<Line> allLineList = lineService.allLineService();
//        ActionContext.getContext().getSession().put("allLineList", allLineList);
        return "delete";
    }
    //修改线路
    @Action(value = "updateLineAction", results = {@Result(name = "update", type = "redirectAction", params = {"actionName", "allLineAction"})})
    public String updateLineType() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        line.setOnTime(sdf.format(new Date()));
        for(int i=0;i<file.length;i++){
            String  path=ServletActionContext.getServletContext().getRealPath("img/"+fileFileName[i]);
            File dest=new File(path);
            try {
                FileUtils.copyFile(file[i], dest);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Picture picture=new Picture();
            picture.setPictureId(pictureId[i]);
            picture.setName("img/"+fileFileName[i]);
            picture.setIntroduction(introduction[i]);
            picture.setLine(line);
            line.getPictureSet().add(picture);
        }
        lineService.updateLineService(line);
        return "update";
    }
    //线路查询
    @Action(value = "findLineAction",results = {@Result(name = "find",type = "redirect",location = "ht/updateLine.jsp")})
    public String findLineType() {
        line = lineService.getLineService(line.getLineId());
        List<Linetype> allLineTypeList = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("allLineTypeList", allLineTypeList);
        ActionContext.getContext().getSession().put("line", line);
        return "find";
    }

       //团购线路查询
    @Action(value = "allTeamLineAction", results = {@Result(name = "all", type = "redirect", location = "ht/seeTeamLine.jsp")})
    public String allTeamLine() {
        //分页
        int totalPages = lineService.getTotalPage(pageSize);
        if (pageIndex < 1) {
            pageIndex=1;
        }else if (pageIndex> totalPages) {
            pageIndex = totalPages;
        }
        ActionContext.getContext().getSession().put("pageIndex",pageIndex);
        ActionContext.getContext().getSession().put("totalPages",totalPages);
        List<Line> allLineList = lineService.allLineService(pageIndex,pageSize);
        ActionContext.getContext().getSession().put("allLineList", allLineList);
        return "all";
    }
    //设置团购信息
    @Action(value = "updateTeamLineAction", results = {@Result(name = "updateTeam", type = "redirectAction",params = {"actionName","allTeamLineAction"})})
    public String updateTeamLineType() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        line.setOnTime(sdf.format(new Date()));
        lineService.updateLineService(line);
        return "updateTeam";
    }
    //查询团购线路
    @Action(value = "findTeamBuyLineAction",results = {@Result(name = "findTeam",type = "redirect",location = "ht/setTeamBuy.jsp")})
    public String findTeamBuyLine(){
        line = lineService.getLineService(line.getLineId());
        List<Linetype> allLineTypeList = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("allLineTypeList", allLineTypeList);
        ActionContext.getContext().getSession().put("line", line);
        return "findTeam";
    }

    public int[] getPictureId() {
        return pictureId;
    }

    public void setPictureId(int[] pictureId) {
        this.pictureId = pictureId;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public File[] getFile() {
        return file;
    }

    public void setFile(File[] file) {
        this.file = file;
    }

    public String[] getFileContentType() {
        return fileContentType;
    }

    public void setFileContentType(String[] fileContentType) {
        this.fileContentType = fileContentType;
    }

    public String[] getFileFileName() {
        return fileFileName;
    }

    public void setFileFileName(String[] fileFileName) {
        this.fileFileName = fileFileName;
    }

    public String[] getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String[] introduction) {
        this.introduction = introduction;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
