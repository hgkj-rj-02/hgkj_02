package com.hgkj.controler.action;

import com.hgkj.model.entity.Linetype;
import com.hgkj.model.service.LineTypeService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class LineTypeAction {
    private Linetype linetype;
    private String message;
    private File file;
    private String fileContentType;
    private String fileFileName;
    @Autowired
    private LineTypeService lineTypeService;

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }

    //查看所有线路类型
    @Action(value = "allLineTypeAction", results = {@Result(name = "all", type = "redirect", location = "ht/seeLineType.jsp")})
    public String allLineType() {
        List<Linetype> allLineTypeList = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("allLineTypeList", allLineTypeList);
        return "all";
    }
    //添加线路类型
    @Action(value = "addLineTypeAction", results = {@Result(name = "add", type = "redirectAction", params = {"actionName", "allLineTypeAction"})})
    public String addLineType() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        linetype.setTime(sdf.format(new Date()));
        //图片上传
        String path= ServletActionContext.getServletContext().getRealPath("img/"+fileFileName);
        File dest=new File(path);
        try {
            FileUtils.copyFile(file,dest);
        } catch (IOException e) {
            e.printStackTrace();
        }
        linetype.setIcon("img/"+fileFileName);
        lineTypeService.addLineTypeService(linetype);
        return "add";
    }

//    @Action(value = "deleteLineTypeAction", results = {@Result(name = "delete", type = "json", params = {"root", "message"})})
    //删除线路类型
    @Action(value = "deleteLineTypeAction", results = {@Result(name = "delete",type = "redirectAction", params = {"actionName", "allLineTypeAction"} )})
    public String deleteLineType() {
          lineTypeService.deleteLineTypeService(linetype.getLineTypeId());
          List<Linetype> allLineTypeList=lineTypeService.allLineTypeService();
          ActionContext.getContext().getSession().put("allLineTypeList",allLineTypeList);

//        boolean result = lineTypeService.deleteLineTypeService(linetype.getLineTypeId());
//        if (result) {
//           List<Linetype> allLineTypeList=lineTypeService.allLineTypeService();
//           ActionContext.getContext().getSession().put("allLineTypeList",allLineTypeList);
//            message = "success";
//        } else {
//            message = "error";
//        }
        return "delete";
    }
       //修改线路类型
    @Action(value = "updateLineTypeAction", results = {@Result(name = "update", type = "redirectAction", params = {"actionName", "allLineTypeAction"})})
    public String updateLineType() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        linetype.setTime(sdf.format(new Date()));
        String path= ServletActionContext.getServletContext().getRealPath("img/"+fileFileName);
        File dest=new File(path);
        try {
            FileUtils.copyFile(file,dest);
        } catch (IOException e) {
            e.printStackTrace();
        }
        linetype.setIcon("img/"+fileFileName);
        lineTypeService.updateLineTypeService(linetype);
        return "update";
    }
    //查询单个线路类型
    @Action(value = "findLineTypeAction",results = {@Result(name = "find",type = "redirect",location = "ht/updateLineType.jsp")})
    public String findLineType() {
        linetype = lineTypeService.getLineTypeService(linetype.getLineTypeId());
        ActionContext.getContext().getSession().put("linetype", linetype);
        return "find";
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getFileContentType() {
        return fileContentType;
    }

    public void setFileContentType(String fileContentType) {
        this.fileContentType = fileContentType;
    }

    public String getFileFileName() {
        return fileFileName;
    }

    public void setFileFileName(String fileFileName) {
        this.fileFileName = fileFileName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Linetype getLinetype() {
        return linetype;
    }

    public void setLinetype(Linetype linetype) {
        this.linetype = linetype;
    }
}
