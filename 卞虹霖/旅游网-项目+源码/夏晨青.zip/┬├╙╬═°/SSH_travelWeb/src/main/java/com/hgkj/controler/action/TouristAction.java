package com.hgkj.controler.action;

import com.hgkj.model.entity.Tourist;
import com.hgkj.model.service.TouristService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class TouristAction {
    private Tourist tourist;
    @Autowired
    private TouristService touristService;

    public void setTouristService(TouristService touristService) {
        this.touristService = touristService;
    }

    @Action(value = "allTouristAction",results = {@Result(name = "all",type = "redirect",location = "qt/allTourist.jsp")})
    public String allTourist() {
        List<Tourist> allTouristList=touristService.allTouristService();
        ActionContext.getContext().getSession().put("allTouristList",allTouristList);
        return "all";
    }
    @Action(value = "addTouristAction",results = {@Result(name = "add",type = "redirectAction",params = {"actionName","allTouristAction"})})
   public String addTourist(){
        touristService.addTouristService(tourist);
       List<Tourist> allTouristList=touristService.allTouristService();
       ActionContext.getContext().getSession().put("allTouristList",allTouristList);
        return "add";
   }
    @Action(value = "deleteTouristAction",results = {@Result(name = "delete",type = "redirectAction",params = {"actionName","allTouristAction"})})
   public String deleteTourist(){
        touristService.deleteTouristService(tourist.getTouristId());
        return "delete";
   }
   @Action(value = "updateTouristAction",results = {@Result(name = "update",type = "redirectAction",params = {"actionName","allTouristAction"})})
   public String updateTourist(){
        touristService.updateTouristService(tourist);
        return "update";
   }
   @Action(value = "findTouristAction",results = {@Result(name = "find",type = "redirect",location = "qt/updateTourist.jsp")})
   public String findTourist(){
     tourist=touristService.getTouristService(tourist.getTouristId());
     ActionContext.getContext().getSession().put("tourist",tourist);
        return "find";
   }
    @Action(value = "findTouristOrderAction",results = {@Result(name = "findTourist",type = "redirect",location = "qt/checkOrder.jsp")})
   public String findTouristOrder(){
       tourist=touristService.getTouristService(tourist.getTouristId());
       ActionContext.getContext().getSession().put("tourist",tourist);
       return "findTourist";
   }

    public Tourist getTourist() {
        return tourist;
    }

    public void setTourist(Tourist tourist) {
        this.tourist = tourist;
    }
}
