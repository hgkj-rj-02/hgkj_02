package com.hgkj.model.dao;

import com.hgkj.model.entity.Orderdetail;

import java.util.List;

public interface OrderDetailDao {
    /**
     * 查看所有订单详情
     * @return
     */
    public List<Orderdetail> allOrderdetail();

    /**
     * 查看某个用户的订单详情
     * @return
     */
    public List<Orderdetail> allOrderdetail(int customerId);

    /**
     * 添加订单的详情
     * @return
     */
    public boolean addOrderDetail(Orderdetail orderdetail);

    /**
     * 删除某个订单的详情
     * @return
     */
    public boolean deleteOrderdetail(String odId);
}
