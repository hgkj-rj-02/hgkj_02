package com.hgkj.controler.action;


import com.hgkj.model.entity.Customer;
import com.hgkj.model.entity.Orderdetail;
import com.hgkj.model.entity.Otdetail;
import com.hgkj.model.service.LineService;
import com.hgkj.model.service.OrderDetailService;
import com.hgkj.model.service.OrderService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class OrderAction {
    private Otdetail otdetail;
    private Orderdetail orderdetail;
    private Customer customer;
    @Autowired
    private OrderService orderService;

    public void setOrderService(OrderService orderService) {
        this.orderService = orderService;
    }
    private OrderDetailService orderDetailService;

@Action(value = "allOrderDetailAction",results = {@Result(name = "allOrderDetail",type = "redirect",location = "qt/orderDetail.jsp")})
    public String allOrderDetail(){
        customer=(Customer) ActionContext.getContext().getSession().get("customer");
        List<Orderdetail> orderdetailList=orderDetailService.allOrderdetailService(customer.getCustomerId());
        ActionContext.getContext().getSession().put("orderdetailList",orderdetailList);
        return "allOrderDetail";
    }
    @Action(value = "allOrderAction",results = {@Result(name = "allOrder",type = "redirect" ,location = "qt/allOrder.jsp")})
    public String allOrder(){
        List<Otdetail> otdetailList=orderService.allOrderService();
        ActionContext.getContext().getSession().put("otdetailList",otdetailList);
        return "allOrder";
    }
    @Action(value = "addOrderAction",results = {@Result(name = "add",type = "redirectAction",params = {"actionName","allOrderAction"})})
    public String addOrder(){
    orderService.addOrderService(otdetail);
        return "add";
    }
    @Action(value = "findOrderAction",results = {@Result(name = "find",type = "redirect",location = "qt/jieSuan.jsp")})
    public String findOrder(){
   otdetail=orderService.getOtIdService(otdetail.getOtId());
  ActionContext.getContext().getSession().put("otdetail",otdetail);
     return "find";
    }
    @Action(value = "deleteOrderAction",results = {@Result(name = "delete",type = "redirectAction",params = {"actionName","allOrderDetailAction"})})
    public String deleteOreder(){
        orderDetailService.deleteOrderdetailService(orderdetail.getOdId());
        return "delete";
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Orderdetail getOrderdetail() {
        return orderdetail;
    }

    public void setOrderdetail(Orderdetail orderdetail) {
        this.orderdetail = orderdetail;
    }

    public Otdetail getOtdetail() {
        return otdetail;
    }

    public void setOtdetail(Otdetail otdetail) {
        this.otdetail = otdetail;
    }
}
