package com.hgkj.model.service;

import com.hgkj.model.entity.Customer;

public interface AdminService {
    /**
     * @param customer
     * @return 管理员登录
     */
    public boolean adminLoginService(Customer customer);
}
