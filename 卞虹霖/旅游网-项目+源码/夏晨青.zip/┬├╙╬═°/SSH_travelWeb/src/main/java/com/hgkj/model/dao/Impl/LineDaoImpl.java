package com.hgkj.model.dao.Impl;

import com.hgkj.model.dao.LineDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Linetype;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class LineDaoImpl implements LineDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Line> allLine(int pageIndex,int pageSize) {
        Query query=getSession().createQuery("from Line").setFirstResult((pageIndex-1)*pageSize).setMaxResults(pageSize);
        return query.list();
    }

    @Override
    public List<Line> lineType() {
        String hql="from Line where linetype.typeName=:typeName";
        Query query=getSession().createQuery(hql).setParameter("typeName","国内游");
        return query.list();
    }

    @Override
    public List<Line> lineType1() {
        String hql="from Line where linetype.typeName=:typeName";
        Query query=getSession().createQuery(hql).setParameter("typeName","国外游");
        return query.list();
    }

    @Override
    public List<Line> lineType2() {
        String hql="from Line where linetype.typeName=:typeName";
        Query query=getSession().createQuery(hql).setParameter("typeName","海岛游");
        return query.list();
    }

    @Override
    public int getTotalPage(int pageSize) {
        String hql="select count(*) from Line";
        long count=(Long) getSession().createQuery(hql).uniqueResult();
        int totalPage=((int) count-1)/pageSize+1;
        return totalPage;
    }

    @Override
    public List<Line> teamLine(int pageIndex,int pageSize) {
        String hql="from Line where teamBuy=1";
        Query query=getSession().createQuery(hql).setFirstResult((pageIndex-1)*pageSize).setMaxResults(pageSize);
        return query.list();
    }

    @Override
    public boolean addLine(Line line) {
        boolean result=false;
        try {
            line.setLinetype(getSession().get(Linetype.class,line.getLinetype().getLineTypeId()));
            this.sessionFactory.getCurrentSession().save(line);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean deleteLine(String lineId) {
        boolean result=false;
        Line line=getSession().get(Line.class,lineId);
        try {
            this.sessionFactory.getCurrentSession().delete(line);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean updateLine(Line line) {
        boolean result=false;
        try {
            this.sessionFactory.getCurrentSession().update(line);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public Line getLine(String lineId) {
        Line line=null;
        try {
            line=(Line) this.sessionFactory.getCurrentSession().get(Line.class,lineId);
        }catch (Exception e){
            e.printStackTrace();
        }
        return line;
    }
}
