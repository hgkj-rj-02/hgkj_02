package com.hgkj.model.dao;

import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.entity.Line;

import java.util.List;

public interface CarDao {
    /**
     * 查看购物车
     * @return
     */
    public List<Car> carList();
    /**
     * 查看某个用户的购物车
     * @return
     */
    public List<Car> carList(int customerId);

    /**
     * 添加购物记录
     * @return
     */
    public boolean addCar(Car car);

    /**
     * 获得客户
     * @param customerId
     * @return
     */
    public Customer getCustomerId(int customerId);
    /**
     * 获取线路
     * @param lineId
     * @return
     */
    public Line getLine(String lineId);

    /**
     * 删除购物记录
     * @return
     */
    public boolean deleteCar(int carId);

    /**
     * 查看单个购物
     * @param carId
     * @return
     */
    public Car getCarId(int carId);
 }
