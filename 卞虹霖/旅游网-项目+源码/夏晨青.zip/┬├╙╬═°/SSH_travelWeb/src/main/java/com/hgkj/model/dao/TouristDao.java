package com.hgkj.model.dao;

import com.hgkj.model.entity.Tourist;

import java.util.List;

public interface TouristDao {
    /**
     * 查询所有线路
     * @return
     */
    public List<Tourist> allTourist();

    /**
     * 添加线路
     * @param tourist
     * @return
     */
    public boolean addTourist(Tourist tourist);

    /**
     * 删除线路
     * @param touristId
     * @return
     */
    public boolean deleteTourist(String touristId);

    /**
     * 修改线路
     * @param tourist
     * @return
     */
    public boolean updateTourist(Tourist tourist);

    /**
     * 获取线路
     * @param touristId
     * @return
     */
    public Tourist getTourist(String touristId);
}
