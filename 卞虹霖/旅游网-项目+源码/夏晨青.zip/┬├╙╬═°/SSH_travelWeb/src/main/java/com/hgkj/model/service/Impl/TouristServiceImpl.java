package com.hgkj.model.service.Impl;

import com.hgkj.model.dao.TouristDao;
import com.hgkj.model.entity.Tourist;
import com.hgkj.model.service.TouristService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TouristServiceImpl implements TouristService {
    @Autowired
    private TouristDao touristDao;

    public void setTouristDao(TouristDao touristDao) {
        this.touristDao = touristDao;
    }

    @Override
    public List<Tourist> allTouristService() {
        return touristDao.allTourist();
    }

    @Override
    public boolean addTouristService(Tourist tourist) {
        return touristDao.addTourist(tourist);
    }

    @Override
    public boolean deleteTouristService(String touristId) {
        return touristDao.deleteTourist(touristId);
    }

    @Override
    public boolean updateTouristService(Tourist tourist) {
        return touristDao.updateTourist(tourist);
    }

    @Override
    public Tourist getTouristService(String touristId) {
        return touristDao.getTourist(touristId);
    }
}
