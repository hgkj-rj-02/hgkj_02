package com.hgkj.model.dao.Impl;

import com.hgkj.model.dao.TouristDao;
import com.hgkj.model.entity.Tourist;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class TouristDaoImpl implements TouristDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Tourist> allTourist() {
        Query query=getSession().createQuery("from Tourist");
        return query.list();
    }

    @Override
    public boolean addTourist(Tourist tourist) {
        boolean result=false;
        try {
            this.sessionFactory.getCurrentSession().save(tourist);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean deleteTourist(String touristId) {
        boolean result=false;
       Tourist tourist=getSession().get(Tourist.class,touristId);
        try {
            this.sessionFactory.getCurrentSession().delete(tourist);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean updateTourist(Tourist tourist) {
        boolean result=false;
        try {
            this.sessionFactory.getCurrentSession().update(tourist);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public Tourist getTourist(String touristId) {
       Tourist tourist=null;
        try {
            tourist=(Tourist) this.sessionFactory.getCurrentSession().get(Tourist.class,touristId);
        }catch (Exception e){
            e.printStackTrace();
        }
        return tourist;
    }
}
