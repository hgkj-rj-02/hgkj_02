package com.hgkj.model.service.Impl;

import com.hgkj.model.dao.CustomerDao;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerDao customerDao;

    public void setCustomerDao(CustomerDao customerDao) {
        this.customerDao = customerDao;
    }

    @Override
    public Customer adminLoginDao(Customer customer) {
        return customerDao.adminLoginDao(customer);
    }

    @Override
    public List<Customer> allCustomer() {
        return customerDao.allCustomer();
    }

    @Override
    public boolean registCutomer(Customer customer) {
        return customerDao.registCutomer(customer);
    }

    @Override
    public Customer getCustomerService(int customerId) {
        return customerDao.getCustomer(customerId);
    }
}
