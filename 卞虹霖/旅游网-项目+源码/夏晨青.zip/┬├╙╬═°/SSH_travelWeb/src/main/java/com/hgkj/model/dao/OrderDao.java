package com.hgkj.model.dao;

import com.hgkj.model.entity.Otdetail;

import java.util.List;

public interface OrderDao {
    /**
     * 查看所有订单详情
     * @return
     */
    public List<Otdetail> allOrder();

    /**
     * 添加订单的详情
     * @return
     */
    public boolean addOrder(Otdetail otdetail);

    /**
     * 删除某个订单的详情
     * @return
     */
    public boolean deleteOrder(int otId);

    /**
     * 获取某个游客订单
     * @param otId
     * @return
     */
    public Otdetail getOtId(int otId);
}
