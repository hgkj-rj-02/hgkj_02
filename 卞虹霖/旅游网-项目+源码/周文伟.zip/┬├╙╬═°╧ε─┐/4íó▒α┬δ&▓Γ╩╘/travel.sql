/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : travel

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 08/07/2019 08:24:40
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for car
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car`  (
  `carId` int(11) NOT NULL AUTO_INCREMENT,
  `customerId` int(11) NOT NULL,
  `lineId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `time` datetime(0) NOT NULL,
  PRIMARY KEY (`carId`) USING BTREE,
  INDEX `Fk_c_cust`(`customerId`) USING BTREE,
  INDEX `Fk_c_line`(`lineId`) USING BTREE,
  CONSTRAINT `Fk_c_cust` FOREIGN KEY (`customerId`) REFERENCES `customer` (`customerId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `Fk_c_line` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer`  (
  `customerId` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(6) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `gender` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `identityId` varchar(18) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tel` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `type` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`customerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES (1, '963397759', 'admin', 'admin', '男', '362322199905036614', '18379632944', 1);
INSERT INTO `customer` VALUES (2, '10086', 'jack', 'jack', '男', '52032262626', '65252525', 0);
INSERT INTO `customer` VALUES (6, '1008611', 'test', '1008611', '男', '362322199905036614', '18672496162', 0);
INSERT INTO `customer` VALUES (7, '100101', 'test01', '100101', '女', '362322199905036614', '18672496162', 0);

-- ----------------------------
-- Table structure for line
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line`  (
  `lineId` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineTypeId` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineName` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `days` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `vehicle` char(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `introduction` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `reason` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `arrange` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `price` decimal(10, 2) NOT NULL,
  `teamBuy` int(11) NULL DEFAULT 0,
  `teamBuyPrice` decimal(10, 2) NULL DEFAULT NULL,
  `beginTime` datetime(0) NULL DEFAULT NULL,
  `endTime` datetime(0) NULL DEFAULT NULL,
  `omTime` datetime(0) NOT NULL,
  PRIMARY KEY (`lineId`) USING BTREE,
  INDEX `Fk_l_lt`(`lineTypeId`) USING BTREE,
  CONSTRAINT `Fk_l_lt` FOREIGN KEY (`lineTypeId`) REFERENCES `linetype` (`lineTypeId`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('6', '2', '九江', '5', '自驾', '萨达', '阿萨德', '地方', 22123.00, 1, 2132.00, '2019-07-06 11:46:38', '2019-07-09 11:46:43', '2019-07-17 11:46:46');
INSERT INTO `line` VALUES ('8', '4', '长沙游', 'sad ', '大巴', '打撒阿萨德', '萨达', '萨达安师大da', 8000.00, 0, 8.00, '2019-07-17 11:44:56', '2019-07-09 11:45:00', '2019-07-07 11:38:34');

-- ----------------------------
-- Table structure for linetype
-- ----------------------------
DROP TABLE IF EXISTS `linetype`;
CREATE TABLE `linetype`  (
  `lineTypeId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `typeName` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `time` datetime(0) NOT NULL,
  `icon` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`lineTypeId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of linetype
-- ----------------------------
INSERT INTO `linetype` VALUES ('1', '一日游', '2019-07-07 11:48:11', 'ht/images/gg.png');
INSERT INTO `linetype` VALUES ('2', '多日游', '2019-07-07 11:36:23', 'ht/images/ls.jpg');
INSERT INTO `linetype` VALUES ('4', '团购游', '2019-07-07 11:37:54', 'ht/images/con2-r.jpg');
INSERT INTO `linetype` VALUES ('8', '境内游', '2019-07-07 11:48:28', 'ht/images/rmdht.png');

-- ----------------------------
-- Table structure for orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail`  (
  `odId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `customerId` int(11) NOT NULL,
  `lineName` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `price` decimal(10, 2) NOT NULL,
  `orderDate` datetime(0) NOT NULL,
  `travelDate` datetime(0) NOT NULL,
  `total` decimal(10, 2) NOT NULL,
  `lineId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`odId`) USING BTREE,
  INDEX `Fk_od_cust`(`customerId`) USING BTREE,
  INDEX `Fk_od_line`(`lineId`) USING BTREE,
  CONSTRAINT `Fk_od_cust` FOREIGN KEY (`customerId`) REFERENCES `customer` (`customerId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `Fk_od_line` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for ot_detail
-- ----------------------------
DROP TABLE IF EXISTS `ot_detail`;
CREATE TABLE `ot_detail`  (
  `otId` int(11) NOT NULL AUTO_INCREMENT,
  `odId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `touristId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`otId`) USING BTREE,
  INDEX `Fk_otd_od`(`odId`) USING BTREE,
  INDEX `Fk_otd_to`(`touristId`) USING BTREE,
  CONSTRAINT `Fk_otd_od` FOREIGN KEY (`odId`) REFERENCES `orderdetail` (`odId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `Fk_otd_to` FOREIGN KEY (`touristId`) REFERENCES `tourist` (`touristId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for picture
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture`  (
  `pictureId` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `pictureName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`pictureId`) USING BTREE,
  INDEX `Fk_p_line`(`lineId`) USING BTREE,
  CONSTRAINT `Fk_p_line` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 88 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of picture
-- ----------------------------
INSERT INTO `picture` VALUES (78, '', 'ht/images/d.jpg', '8');
INSERT INTO `picture` VALUES (79, '', 'ht/images/con2-r1.jpg', '8');
INSERT INTO `picture` VALUES (80, '', 'ht/images/conl.jpg', '8');

-- ----------------------------
-- Table structure for tourist
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist`  (
  `touristId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `IDCard` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tel` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `realName` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`touristId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tourist
-- ----------------------------
INSERT INTO `tourist` VALUES ('1', '362322199905036614', '18379632944', 'youke');

SET FOREIGN_KEY_CHECKS = 1;
