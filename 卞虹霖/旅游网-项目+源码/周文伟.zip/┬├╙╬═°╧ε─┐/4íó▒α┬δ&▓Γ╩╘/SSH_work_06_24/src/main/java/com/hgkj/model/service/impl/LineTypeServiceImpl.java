package com.hgkj.model.service.impl;

import com.hgkj.model.dao.LineTypeDao;
import com.hgkj.model.entity.LineType;
import com.hgkj.model.service.LineTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: 周文伟
 * @Date: 2019/6/24 23:34
 * @Version 1.8
 */
@Service
public class LineTypeServiceImpl implements LineTypeService {
    @Autowired
    private LineTypeDao lineTypeDao;

    public void setLineTypeDao(LineTypeDao lineTypeDao) {
        this.lineTypeDao = lineTypeDao;
    }

    @Override
    public List<LineType> allLineTypeService() {
        return lineTypeDao.allLineTypeDao();
    }

    @Override
    public void addLineTypeService(LineType lineType) {
        lineTypeDao.addLineTypeDao(lineType);
    }

    @Override
    public void deleteLineTypeService(String lineTypeId) {
        lineTypeDao.deleteLineTypeDao(lineTypeId);
    }

    @Override
    public void updateLineTypeService(LineType lineType) {
        lineTypeDao.updateLineTypeDao(lineType);
    }

    @Override
    public LineType getByIdLineTypeService(String lineTypeId) {
        return lineTypeDao.getByIdLineTypeDao(lineTypeId);
    }
}
