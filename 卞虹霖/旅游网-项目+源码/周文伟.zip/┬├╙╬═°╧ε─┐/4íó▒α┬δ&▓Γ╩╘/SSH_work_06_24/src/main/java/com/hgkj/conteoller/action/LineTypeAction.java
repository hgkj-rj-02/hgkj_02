package com.hgkj.conteoller.action;

import com.hgkj.model.entity.LineType;
import com.hgkj.model.service.LineTypeService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * @Author: 周文伟
 * @Date: 2019/6/24 23:41
 * @Version 1.8
 */
@Controller

@Namespace("/")
@ParentPackage("json-default")
public class LineTypeAction {
    private File file;
    private String fileContentType;
    private String fileFileName;

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getFileContentType() {
        return fileContentType;
    }

    public void setFileContentType(String fileContentType) {
        this.fileContentType = fileContentType;
    }

    public String getFileFileName() {
        return fileFileName;
    }

    public void setFileFileName(String fileFileName) {
        this.fileFileName = fileFileName;
    }

    private LineType lineType;

    public LineType getLineType() {
        return lineType;
    }

    public void setLineType(LineType lineType) {
        this.lineType = lineType;
    }

    private List<LineType> lineTypeList;

    public List<LineType> getLineTypeList() {
        return lineTypeList;
    }

    public void setLineTypeList(List<LineType> lineTypeList) {
        this.lineTypeList = lineTypeList;
    }

    @Autowired
    private LineTypeService lineTypeService;

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }

    @Action(value = "allLineTypeAction", results = {@Result(name = "all", type = "redirect", location = "ht/lineType.jsp")})
    public String allLineType() {
        lineTypeList = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("lineTypeList", lineTypeList);
        return "all";
    }

    @Action(value = "allLL", results = {@Result(name = "find", type = "json", params = {"root","lineTypeList"})})
    public String allLL() {
        lineTypeList = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("lineTypeList", lineTypeList);
        return "find";
    }

    @Action(value = "addLineTypeAction", results = {@Result(name = "add", type = "redirectAction",
            params = {"actionName", "allLineTypeAction"})})
    public String addLineType()throws IOException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        lineType.setTime(Timestamp.valueOf(sdf.format(new Date())));

        String target = ServletActionContext.getServletContext().getRealPath("ht/images/" + fileFileName);
        File fileTarget = new File(target);
        FileUtils.copyFile(file,fileTarget);
        lineType.setIcon("ht/images/" + fileFileName);
        lineTypeService.addLineTypeService(lineType);
        return "add";
    }

    @Action(value = "deleteLineTypeAction", results = {@Result(name = "delete", type = "redirectAction",
            params = {"actionName", "allLineTypeAction"})})
    public String deleteLineType() {
        lineTypeService.deleteLineTypeService(lineType.getLineTypeId());
        return "delete";
    }

    @Action(value = "updateLineType", results = {@Result(name = "update", type = "redirectAction",
            params = {"actionName", "allLineTypeAction"})})
    public String updateLineType() throws IOException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        lineType.setTime(Timestamp.valueOf(sdf.format(new Date())));

        String target =ServletActionContext.getServletContext().getRealPath("ht/images/"+fileFileName);
        File fileTarget = new File(target);
        FileUtils.copyFile(file,fileTarget);
        lineType.setIcon("ht/images/" + fileFileName);
        lineTypeService.updateLineTypeService(lineType);
        return "update";
    }

    @Action(value = "findLineType", results = {@Result(name = "find", type = "redirect",
            location = "ht/updateLineType.jsp")})
    public String findLineType() {
        lineType = lineTypeService.getByIdLineTypeService(lineType.getLineTypeId());
        ActionContext.getContext().getSession().put("lineType", lineType);
        return "find";
    }


}
