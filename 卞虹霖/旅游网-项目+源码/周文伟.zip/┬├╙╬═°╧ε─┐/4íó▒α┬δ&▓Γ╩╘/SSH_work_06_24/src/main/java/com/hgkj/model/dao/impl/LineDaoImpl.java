package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.LineDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.LineType;
import com.opensymphony.xwork2.ActionContext;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @Author: 周文伟
 * @Date: 2019/6/25 14:20
 * @Version 1.8
 */
@Repository
@Transactional
public class LineDaoImpl implements LineDao {
    @Autowired
    private SessionFactory sessionFactory;

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Line> allLineDao() {
        Query query =  getSession().createQuery("from Line");
        return query.list();
    }

    @Override
    public Line getLineByIdDao(String lineId) {
        Line line = getSession().get(Line.class,lineId);
        return line;
    }

    @Override
    public void updateTeamLineDao(Line line) {
        if (line.getTeamBuyPrice() != null){
            line.setTeamBuy(1);
        }else {
            line.setTeamBuy(0);
        }
        line.setLineType(getSession().get(LineType.class,line.getLineType().getLineTypeId()));
        getSession().update(line);
    }

    @Override
    public void updateLineDao(Line line) {
        getSession().update(line);
    }

    @Override
    public Line findLineDao(String lineId) {
         Line line = getSession().get(Line.class,lineId);
         return line;
    }

    @Override
    public void deleteLineDao(String lineId) {
        Line line = getSession().get(Line.class,lineId);
        getSession().delete(line);
    }

    @Override
    public void addLineDao(Line line) {
        line.setLineType(getSession().get(LineType.class,line.getLineType().getLineTypeId()));
        getSession().save(line);
    }
}
