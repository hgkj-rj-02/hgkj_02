package com.hgkj.model.dao;

import com.hgkj.model.entity.Line;
import org.w3c.dom.stylesheets.LinkStyle;

import java.util.List;

/**
 * @Author: 周文伟
 * @Date: 2019/6/24 23:17
 * @Version 1.8
 */
public interface LineDao {
    public List<Line> allLineDao();
    public Line getLineByIdDao(String lineId);
    public void updateTeamLineDao(Line line);
    public void deleteLineDao(String lineId);
    public void addLineDao(Line line);

    public void updateLineDao(Line line);
    public Line findLineDao(String lineId);

}
