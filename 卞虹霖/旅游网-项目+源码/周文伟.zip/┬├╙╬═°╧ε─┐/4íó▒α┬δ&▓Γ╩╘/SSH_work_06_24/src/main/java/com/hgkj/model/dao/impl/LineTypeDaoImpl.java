package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.LineTypeDao;
import com.hgkj.model.entity.LineType;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;

/**
 * @Author: 周文伟
 * @Date: 2019/6/24 23:23
 * @Version 1.8
 */
@Repository
@Transactional
public class LineTypeDaoImpl implements LineTypeDao {
    @Autowired
    private SessionFactory sessionFactory;

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<LineType> allLineTypeDao() {
        Query query =  getSession().createQuery("from LineType");
        return query.list();
    }

    @Override
    public void addLineTypeDao(LineType lineType) {
        getSession().save(lineType);
    }

    @Override
    public void deleteLineTypeDao(String lineTypeId) {
        LineType lineType = getSession().get(LineType.class,lineTypeId);
        getSession().delete(lineType);
    }

    @Override
    public void updateLineTypeDao(LineType lineType) {
        getSession().update(lineType);
    }

    @Override
    public LineType getByIdLineTypeDao(String lineTypeId) {
        return  getSession().get(LineType.class,lineTypeId);
    }
}
