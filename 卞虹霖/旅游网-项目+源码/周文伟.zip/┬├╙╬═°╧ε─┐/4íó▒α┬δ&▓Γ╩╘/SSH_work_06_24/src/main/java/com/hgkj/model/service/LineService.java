package com.hgkj.model.service;

import com.hgkj.model.entity.Line;

import java.util.List;

/**
 * @Author: 周文伟
 * @Date: 2019/6/25 14:22
 * @Version 1.8
 */
public interface LineService {
    public List<Line> allLineService();
    public Line getLineByIdService(String lineId);
    public void updateTeamLineService(Line line);
    public void deleteLineService(String lineId);
    public void addLineService(Line line);
    public void updateLineService(Line line);
    public Line findLineService(String lineId);
    }
