package com.hgkj.model.service;

import com.hgkj.model.entity.Customer;

/**
 * @Author: 周文伟
 * @Date: 2019/6/24 9:08
 * @Version 1.8
 */
public interface CustomerService {
    public Customer adminLoginService(Customer customer);
    public void addCustomerDao(Customer customer);
    public Customer custmoerLoginDao(Customer customer);
}
