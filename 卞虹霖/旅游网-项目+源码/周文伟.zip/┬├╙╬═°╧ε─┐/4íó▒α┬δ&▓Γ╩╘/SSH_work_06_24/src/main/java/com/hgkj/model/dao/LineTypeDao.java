package com.hgkj.model.dao;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.LineType;

import java.util.List;

/**
 * @Author: 周文伟
 * @Date: 2019/6/24 23:19
 * @Version 1.8
 */
public interface LineTypeDao {
    public List<LineType> allLineTypeDao();
    public void addLineTypeDao(LineType lineType);
    public void deleteLineTypeDao(String lineTypeId);
    public void updateLineTypeDao(LineType lineType);
    public LineType getByIdLineTypeDao(String lineTypeId);
}
