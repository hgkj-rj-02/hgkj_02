package com.hgkj.model.service;

import com.hgkj.model.entity.LineType;

import java.util.List;

/**
 * @Author: 周文伟
 * @Date: 2019/6/24 23:32
 * @Version 1.8
 */
public interface LineTypeService {
    public List<LineType> allLineTypeService();
    public void addLineTypeService(LineType lineType);
    public void deleteLineTypeService(String lineTypeId);
    public void updateLineTypeService(LineType lineType);
    public LineType getByIdLineTypeService(String lineTypeId);
}
