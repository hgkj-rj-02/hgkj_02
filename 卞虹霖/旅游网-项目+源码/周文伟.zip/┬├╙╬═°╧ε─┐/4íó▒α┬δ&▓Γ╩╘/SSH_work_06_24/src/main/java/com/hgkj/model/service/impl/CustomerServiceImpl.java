package com.hgkj.model.service.impl;

import com.hgkj.model.dao.CustomerDao;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Author: 周文伟
 * @Date: 2019/6/24 9:08
 * @Version 1.8
 */
@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerDao customerDao;

    public CustomerDao getCustomerDao() {
        return customerDao;
    }

    public void setCustomerDao(CustomerDao customerDao) {
        this.customerDao = customerDao;
    }

    @Override
    public Customer adminLoginService(Customer customer) {
        return customerDao.adminLoginDao(customer);
    }

    @Override
    public void addCustomerDao(Customer customer) {
        customerDao.addCustomerDao(customer);
    }

    @Override
    public Customer custmoerLoginDao(Customer customer) {
        return customerDao.custmoerLoginDao(customer);
    }
}
