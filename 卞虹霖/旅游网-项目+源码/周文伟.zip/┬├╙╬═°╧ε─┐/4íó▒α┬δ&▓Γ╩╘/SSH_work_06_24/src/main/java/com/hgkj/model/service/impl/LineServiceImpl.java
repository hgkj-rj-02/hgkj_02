package com.hgkj.model.service.impl;

import com.hgkj.model.dao.LineDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.service.LineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: 周文伟
 * @Date: 2019/6/25 14:22
 * @Version 1.8
 */
@Service
public class LineServiceImpl implements LineService {
    @Autowired
    private LineDao lineDao;

    public void setLineDao(LineDao lineDao) {
        this.lineDao = lineDao;
    }

    @Override
    public List<Line> allLineService() {
        return lineDao.allLineDao();
    }

    @Override
    public Line getLineByIdService(String lineId) {
        return lineDao.getLineByIdDao(lineId);
    }

    @Override
    public void updateTeamLineService(Line line) {
        lineDao.updateTeamLineDao(line);
    }

    @Override
    public void deleteLineService(String lineId) {
        lineDao.deleteLineDao(lineId);
    }

    @Override
    public void addLineService(Line line) {
        lineDao.addLineDao(line);
    }

    @Override
    public void updateLineService(Line line) {
        lineDao.updateLineDao(line);
    }

    @Override
    public Line findLineService(String lineId) {
        return lineDao.findLineDao(lineId);
    }
}
