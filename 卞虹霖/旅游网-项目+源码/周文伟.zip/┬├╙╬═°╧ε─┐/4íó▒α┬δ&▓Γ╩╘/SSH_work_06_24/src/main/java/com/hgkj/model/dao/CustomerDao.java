package com.hgkj.model.dao;

import com.hgkj.model.entity.Customer;
import org.omg.CORBA.PUBLIC_MEMBER;

/**
 * @Author: 周文伟
 * @Date: 2019/6/24 8:55
 * @Version 1.8
 */
public interface CustomerDao {
    public Customer adminLoginDao(Customer customer);
    public void addCustomerDao(Customer customer);
    public Customer custmoerLoginDao(Customer customer);
}
