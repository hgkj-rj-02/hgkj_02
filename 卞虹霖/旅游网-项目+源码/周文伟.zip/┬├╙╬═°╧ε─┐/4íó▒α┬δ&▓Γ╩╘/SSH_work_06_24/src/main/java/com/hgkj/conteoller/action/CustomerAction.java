package com.hgkj.conteoller.action;

import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CustomerService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import sun.plugin2.message.Message;

/**
 * @Author: 周文伟
 * @Date: 2019/6/24 9:13
 * @Version 1.8
 */
@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class CustomerAction {
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    private Customer customer;

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    @Autowired
    private CustomerService customerService;

    public CustomerService getCustomerService() {
        return customerService;
    }

    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }

    @Action(value = "adminLogin",results ={@Result(name = "admin",type = "redirect",location = "ht/index.jsp")
            ,@Result(name ="adminError",type = "redirect",location = "qt/login.jsp")
            })
    public String adminLogin(){
        Customer customer1=customerService.adminLoginService(customer);
        if(customer1.getType()==1 ){
            ActionContext.getContext().getSession().put("customer1",customer1);
            return "admin";
        }else{
            message="对不起您不是管理员！请在此处登录";
            ActionContext.getContext().getSession().put("message",message);
            return "adminError";
        }
    }


    @Action(value = "customerLoginAction",results = {@Result(name = "custLogin",type = "redirect",location = "qt/index.jsp")})
    public String customerLogin(){
        Customer customer2=customerService.custmoerLoginDao(customer);
        ActionContext.getContext().getSession().put("customer2",customer2);
        return "custLogin";
    }

    @Action(value ="addCustomerAction",results = {@Result(name = "addCust",type = "redirect",location = "qt/login.jsp")})
    public String addCustomer(){
        customer.setType(0);
        customerService.addCustomerDao(customer);
        return "addCust";
    }

}
