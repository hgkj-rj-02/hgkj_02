package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.CustomerDao;
import com.hgkj.model.entity.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * @Author: 周文伟
 * @Date: 2019/6/24 8:55
 * @Version 1.8
 */
@Repository
@Transactional

public class CustomerDaoImpl implements CustomerDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();

    }


    @Override
    public Customer adminLoginDao(Customer customer) {
        String hql = "from Customer where account=:name and password=:name1";
        customer= (Customer) getSession().createQuery(hql).setParameter("name",customer.getAccount()).setParameter("name1",customer.getPassword()).uniqueResult();
        return customer;
    }



    @Override
    public void addCustomerDao(Customer customer) {
        getSession().save(customer);
    }

    @Override
    public Customer custmoerLoginDao(Customer customer) {
        String hql = "from Customer where account=:name and password=:name1 ";
        customer= (Customer) getSession().createQuery(hql).setParameter("name",customer.getAccount()).setParameter("name1",customer.getPassword()).uniqueResult();
        return customer;
    }
}
