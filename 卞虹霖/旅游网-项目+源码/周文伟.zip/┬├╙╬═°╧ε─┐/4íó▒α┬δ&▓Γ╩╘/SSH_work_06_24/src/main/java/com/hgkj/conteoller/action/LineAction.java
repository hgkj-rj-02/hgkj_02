package com.hgkj.conteoller.action;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.LineType;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.LineService;
import com.hgkj.model.service.LineTypeService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * @Author: 周文伟
 * @Date: 2019/6/25 14:25
 * @Version 1.8
 */
@Controller
@Namespace("/")
@ParentPackage("json-default")
public class LineAction {
    private File[] file;
    private String[] fileContentType;
    private String[] fileFileName;
    private String[] introduction;

    public String[] getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String[] introduction) {
        this.introduction = introduction;
    }


    public File[] getFile() {
        return file;
    }

    public void setFile(File[] file) {
        this.file = file;
    }

    public String[] getFileContentType() {
        return fileContentType;
    }

    public void setFileContentType(String[] fileContentType) {
        this.fileContentType = fileContentType;
    }

    public String[] getFileFileName() {
        return fileFileName;
    }

    public void setFileFileName(String[] fileFileName) {
        this.fileFileName = fileFileName;
    }

    private Line line;

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Autowired
    private LineTypeService lineTypeService;

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }

    @Autowired
    private LineService lineService;

    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }

    private List<Line> lineList;

    public List<Line> getLineList() {
        return lineList;
    }

    public void setLineList(List<Line> lineList) {
        this.lineList = lineList;
    }

    @Action(value = "allLineAction", results = {@Result(name = "all", type = "redirect", location = "ht/line.jsp")})
    public String allLine() {
        lineList = lineService.allLineService();
        ActionContext.getContext().getSession().put("lineList", lineList);
        return "all";
    }

    @Action(value = "allTeamLineAction", results = {@Result(name = "allTeam", type = "redirect", location = "ht/team_line.jsp")})
    public String allTeamLine() {
        lineList = lineService.allLineService();
        ActionContext.getContext().getSession().put("lineList", lineList);
        return "allTeam";
    }

    @Action(value = "findTeamLineAction", results = {@Result(name = "findTeam", type = "redirect", location = "ht/updateTeamLine.jsp")})
    public String findTeamLine() {
        Line line1 = lineService.getLineByIdService(line.getLineId());
        List<LineType> lineTypes = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("line1", line1);
        ActionContext.getContext().getSession().put("lineTypes", lineTypes);
        return "findTeam";
    }

    @Action(value = "deleteLineAction", results = {@Result(name = "deleteLine", type = "redirectAction",
            params = {"actionName", "allLineAction"})})
    public String deleteLine() {
        lineService.deleteLineService(line.getLineId());
        return "deleteLine";
    }

    @Action(value = "updateTeamLineAction", results = {@Result(name = "updateTeamLine", type = "redirectAction",
            params = {"actionName", "allTeamLineAction"}
    )})
    public String updateTeamLine() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        line.setOmTime(Timestamp.valueOf(sdf.format(new Date())));
        lineService.updateTeamLineService(line);
        return "updateTeamLine";
    }



    @Action(value = "addLineAction", results = {@Result(name = "add", type = "redirectAction",
            params = {"actionName", "allLineAction"}
    )})
    public String addLine() throws IOException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        line.setOmTime(Timestamp.valueOf(sdf.format(new Date())));

        for (int i = 0; i < file.length; i++) {
            String target = ServletActionContext.getServletContext().getRealPath("ht/images/" + fileFileName[i]);
            File fileTarget = new File(target);
            FileUtils.copyFile(file[i], fileTarget);
            Picture picture=new Picture();
            picture.setPictureName("ht/images/" + fileFileName[i]);
            picture.setIntroduction(introduction[i]);
            picture.setLine(line);
            line.getPictureSet().add(picture);
        }
        lineService.addLineService(line);
        return "add";
    }


    @Action(value = "updateLineAction", results = {@Result(name = "update", type = "redirectAction",
            params = {"actionName", "allLineAction"}
    )})
    public String updateLine() throws IOException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        line.setOmTime(Timestamp.valueOf(sdf.format(new Date())));

        for (int i = 0; i < file.length; i++) {
            String target = ServletActionContext.getServletContext().getRealPath("ht/images/" + fileFileName[i]);
            File fileTarget = new File(target);
            FileUtils.copyFile(file[i], fileTarget);
            Picture picture=new Picture();
            picture.setPictureName("ht/images/" + fileFileName[i]);
            picture.setIntroduction(introduction[i]);
            picture.setLine(line);
            line.getPictureSet().add(picture);
        }
        lineService.updateLineService(line);
        return "update";
    }

    @Action(value = "findLineAction",results = {@Result(name = "find",type = "redirect",location = "ht/updateLine.jsp")})
    public String findLine(){
        Line line2 =lineService.findLineService(line.getLineId());
        ActionContext.getContext().getSession().put("line2",line2);
        return "find";
    }
}
