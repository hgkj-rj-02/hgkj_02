/*
Navicat MySQL Data Transfer

Source Server         : Sakurary
Source Server Version : 50724
Source Host           : localhost:3306
Source Database       : tour

Target Server Type    : MYSQL
Target Server Version : 50724
File Encoding         : 65001

Date: 2019-07-09 07:56:06
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `car`
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car` (
  `carID` int(11) NOT NULL AUTO_INCREMENT,
  `customerID` int(11) NOT NULL,
  `lineID` varchar(36) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`carID`),
  KEY `c_1` (`customerID`),
  KEY `l_1` (`lineID`),
  CONSTRAINT `c_1` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`),
  CONSTRAINT `l_1` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of car
-- ----------------------------

-- ----------------------------
-- Table structure for `customer`
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `customerID` int(10) NOT NULL AUTO_INCREMENT,
  `account` varchar(12) NOT NULL,
  `name` varchar(6) NOT NULL,
  `password` varchar(12) NOT NULL,
  `gender` char(2) NOT NULL,
  ` identityID` varchar(18) NOT NULL,
  `tel` varchar(11) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `identityID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`customerID`),
  UNIQUE KEY `account` (`account`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES ('1', 'haha', 'jack', 'jack', '男', '322123321234432123', '13233332222', null, null);
INSERT INTO `customer` VALUES ('2', 'admin', 'admin', 'admin', '男', '746251736546372837', '14673711821', '1', null);

-- ----------------------------
-- Table structure for `line`
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line` (
  `lineID` varchar(12) NOT NULL,
  `lineTypeID` varchar(12) NOT NULL,
  `lineName` varchar(15) NOT NULL,
  `days` varchar(12) NOT NULL,
  `vehicle` char(2) NOT NULL,
  `introduction` varchar(400) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `arrange` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `teamBuy` int(11) DEFAULT NULL,
  `teamBuyPrice` decimal(10,2) DEFAULT NULL,
  `beginTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `onTime` datetime NOT NULL,
  PRIMARY KEY (`lineID`),
  KEY `lti_1` (`lineTypeID`),
  CONSTRAINT `lti_1` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('1001', '56464a', '凤凰古城', '5', '火车', '张家界土家风情园坐落在风景明珠张家界市境内。交通十分便利，距机场、火车站仅十分钟车程。园区占地80余亩,总投资7500万元，是一座人文景观与自然景观相融合，集旅游观光、文艺表演、奇珍展览、住宿、餐饮、娱乐、购物等于一体的大型综合性旅游服务企业。', '含3早6正，早餐6元/人/餐，正餐15元/人/餐（十人一桌、四荤四素、八菜一汤、不含酒水）', '第一天：················· 第二天：················', '2988.00', '1', '2888.00', '2019-06-18 10:50:25', '2019-06-20 10:50:35', '2019-06-15 10:50:47');
INSERT INTO `line` VALUES ('1002', '56464a', '云南大理', '3', '火车', '好', '好', '自行安排', '1999.00', '1', '1899.00', '2019-06-17 10:55:48', '2019-06-20 10:55:54', '2019-06-15 10:55:04');
INSERT INTO `line` VALUES ('1003', '56464a', '昆明', '2', '飞机', '好', '好', '自由安排', '1588.00', null, null, null, null, '2019-06-16 10:57:23');
INSERT INTO `line` VALUES ('1004', '56464a', '丽江', '2', '飞机', '好', '好', '玩', '2100.00', null, null, null, null, '2019-06-16 10:58:32');
INSERT INTO `line` VALUES ('1005', '56464a', '西双版纳', '5', '飞机', '好', '好', '玩', '3199.00', null, null, null, null, '2019-06-16 10:59:26');
INSERT INTO `line` VALUES ('1006', '56464a', '九寨沟', '3', '火车', '好', '好', '玩', '1000.00', null, null, null, null, '2019-06-16 11:00:39');
INSERT INTO `line` VALUES ('1007', 'jw020', '奥地利', '2', '飞机', '好', '好', '玩', '6999.00', null, null, null, null, '2019-06-17 11:05:08');
INSERT INTO `line` VALUES ('1008', 'jw020', '马尔代夫', '2', '飞机', '好', '好', '玩', '7688.00', '1', '6999.00', '2019-06-18 11:06:07', '2019-06-20 11:06:16', '2019-06-17 11:06:19');
INSERT INTO `line` VALUES ('1009', 'jw020', '夏威夷', '7', '飞机', '好', '好', '玩', '9999.00', '1', '8999.00', '2019-06-18 11:07:53', '2019-06-20 11:08:00', '2019-06-17 11:08:04');
INSERT INTO `line` VALUES ('1010', 'hd030', '北海道', '3', '飞机', '好', '好', '玩', '4999.00', null, null, null, null, '2019-06-17 00:00:00');
INSERT INTO `line` VALUES ('1011', 'hd030', '巴厘岛', '1', '飞机', '好', '好', '玩', '6469.00', null, null, null, null, '2019-06-17 00:00:00');
INSERT INTO `line` VALUES ('1012', 'zj040', '张家界', '4', '自驾', '好', '好', '玩', '799.00', null, null, null, null, '2019-06-16 11:11:53');
INSERT INTO `line` VALUES ('1013', 'zj040', '武当山', '1', '自驾', '好', '好', '玩', '699.00', null, null, null, null, '2019-06-16 11:13:04');
INSERT INTO `line` VALUES ('1014', 'zj040', '黄山', '2', '自驾', '好', '好', '玩', '99.00', null, null, null, null, '2019-06-16 11:13:39');
INSERT INTO `line` VALUES ('1015', 'jw020', '[全国联保]德国2日', '2', '飞机', '德国，是一个中欧联邦会议共和制...', '含2早4正', '第一日：。。。。', '12348.00', '1', '8888.00', '2019-07-17 15:46:55', '2019-07-18 15:47:04', '2019-07-17 15:47:09');
INSERT INTO `line` VALUES ('1016', 'jw020', '[全国联保] 希腊3日游', '3', '飞机', '希腊被誉为是西方文明的发源地...', 'asdasdadad', '123123123', '13129.00', '1', '9878.00', '2019-07-17 15:48:42', '2019-07-18 15:48:49', '2019-07-17 15:48:54');

-- ----------------------------
-- Table structure for `linetype`
-- ----------------------------
DROP TABLE IF EXISTS `linetype`;
CREATE TABLE `linetype` (
  `lineTypeID` varchar(36) NOT NULL,
  `typeName` varchar(10) NOT NULL,
  `time` datetime NOT NULL,
  `icon` varchar(20) NOT NULL,
  PRIMARY KEY (`lineTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of linetype
-- ----------------------------
INSERT INTO `linetype` VALUES ('56464a', '境内游', '2019-06-27 10:26:09', 'jn.jpg');
INSERT INTO `linetype` VALUES ('hd030', '海岛游', '2019-06-14 10:42:33', 'hd.jpg');
INSERT INTO `linetype` VALUES ('jw020', '境外游', '2019-06-20 10:40:31', 'jw.jpg');
INSERT INTO `linetype` VALUES ('zj040', '自驾游', '2019-06-15 10:43:22', 'zj.jpg');

-- ----------------------------
-- Table structure for `orderdetail`
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail` (
  `odID` varchar(36) NOT NULL,
  `customerID` int(11) NOT NULL,
  `lineName` varchar(15) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `orderDate` datetime NOT NULL,
  `travwlDate` datetime NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `lineID` varchar(255) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`odID`),
  KEY `c_2` (`customerID`),
  KEY `l_3` (`lineID`),
  CONSTRAINT `c_2` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`),
  CONSTRAINT `l_3` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderdetail
-- ----------------------------

-- ----------------------------
-- Table structure for `ot_detail`
-- ----------------------------
DROP TABLE IF EXISTS `ot_detail`;
CREATE TABLE `ot_detail` (
  `otID` int(11) NOT NULL AUTO_INCREMENT,
  `odID` varchar(36) NOT NULL,
  `touristID` varchar(36) NOT NULL,
  PRIMARY KEY (`otID`),
  KEY `o_1` (`odID`),
  KEY `t_1` (`touristID`),
  CONSTRAINT `o_1` FOREIGN KEY (`odID`) REFERENCES `orderdetail` (`odID`),
  CONSTRAINT `t_1` FOREIGN KEY (`touristID`) REFERENCES `tourist` (`touristID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ot_detail
-- ----------------------------

-- ----------------------------
-- Table structure for `picture`
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture` (
  `pictureID` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` varchar(20) NOT NULL,
  `pName` varchar(20) NOT NULL,
  `lineID` varchar(36) NOT NULL,
  PRIMARY KEY (`pictureID`),
  KEY `l_2` (`lineID`),
  CONSTRAINT `l_2` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB AUTO_INCREMENT=1003 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of picture
-- ----------------------------
INSERT INTO `picture` VALUES ('1001', '图片介绍', 'pic.jpg', '1001');
INSERT INTO `picture` VALUES ('1002', '图片介绍', 'pic1.jpg', '1002');

-- ----------------------------
-- Table structure for `tourist`
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist` (
  `touristID` varchar(36) NOT NULL,
  `IDCard` varchar(36) NOT NULL,
  `tel` varchar(15) NOT NULL,
  `realName` varchar(20) NOT NULL,
  PRIMARY KEY (`touristID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tourist
-- ----------------------------
INSERT INTO `tourist` VALUES ('a0001', '412358472837483728', '13333333333', '张三');
