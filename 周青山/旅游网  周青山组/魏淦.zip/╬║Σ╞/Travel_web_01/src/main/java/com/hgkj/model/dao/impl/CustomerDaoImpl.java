package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.CustomerDao;
import com.hgkj.model.entity.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class CustomerDaoImpl implements CustomerDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public boolean customerLoginDao(Customer customer) {
        Query query = getSession().createQuery("from Customer where name='"+customer.getName()+"'and password='"+customer.getPassword()+"'");
        if (query.list().size()>0){
            return true;
        }else {
            return false;
        }

    }

    @Override
    public boolean customerAdminLoginDao(Customer customer) {
        Query query=getSession().createQuery("from Customer where name='"+customer.getName()+"' and password= '"+customer.getPassword()+"'");
        if (query.list().size()>0){
            return true;
        }else {
            return false;
        }

    }

    @Override
    public void addCustoemrDao(Customer customer) {
        getSession().save(customer);
    }

    @Override
    public Customer getCustomerByName(Customer customer) {
        Query query=getSession().createQuery("from Customer where name='"+customer.getName()+"'and password='"+customer.getPassword()+"'");
        return (Customer) query.uniqueResult();
    }
}
