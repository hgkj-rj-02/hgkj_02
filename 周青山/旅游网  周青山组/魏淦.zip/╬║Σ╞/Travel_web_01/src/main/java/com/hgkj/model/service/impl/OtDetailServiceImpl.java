package com.hgkj.model.service.impl;

import com.hgkj.model.dao.OtDetailDao;
import com.hgkj.model.entity.OtDetail;
import com.hgkj.model.service.OtDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OtDetailServiceImpl implements OtDetailService {
    @Autowired
    private OtDetailDao otDetailDao;
    @Override
    public void addOtDetailService(OtDetail OtDetail) {
        otDetailDao.addOtDetailDao(OtDetail);
    }

    @Override
    public void deleteOtDetailService(int OtDetailId) {
        otDetailDao.deleteOtDetailDao(OtDetailId);
    }

    @Override
    public void changeOtDetailService(OtDetail OtDetail) {
        otDetailDao.changeOtDetailDao(OtDetail);
    }

    @Override
    public OtDetail getOtDetailService(int OtDetailId) {
        return otDetailDao.getOtDetailDao(OtDetailId);
    }

    @Override
    public List<OtDetail> allOtDetailService() {
        return otDetailDao.allOtDetailDao();
    }
}
