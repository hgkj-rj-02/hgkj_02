package com.hgkj.model.dao;

import com.hgkj.model.entity.OtDetail;

import java.util.List;

public interface OtDetailDao {
    public void addOtDetailDao(OtDetail OtDetail);
    public void deleteOtDetailDao(int OtDetailId);
    public void changeOtDetailDao(OtDetail OtDetail);
    public OtDetail getOtDetailDao(int OtDetailId);
    public List<OtDetail> allOtDetailDao();
}
