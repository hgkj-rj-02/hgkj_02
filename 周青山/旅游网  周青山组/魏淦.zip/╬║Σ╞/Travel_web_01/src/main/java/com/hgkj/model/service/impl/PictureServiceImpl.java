package com.hgkj.model.service.impl;

import com.hgkj.model.dao.PictureDao;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.PictureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PictureServiceImpl implements PictureService {
    @Autowired
    private PictureDao pictureDao;
    @Override
    public void addPictureService(Picture Picture) {
        pictureDao.addPictureDao(Picture);
    }

    @Override
    public void deletePictureService(String PictureId) {
        pictureDao.deletePictureDao(PictureId);
    }

    @Override
    public void changePictureDaoService(Picture Picture) {
            pictureDao.changePictureDao(Picture);
    }

    @Override
    public Picture getPictureService(String PictureId) {
        return pictureDao.getPictureDao(PictureId);
    }

    @Override
    public List<Picture> allPictureService() {
        return pictureDao.allPictureDao();
    }

    @Override
    public Picture getPictureByLineIdService(String LineId) {
        return pictureDao.getPictureByLineIdDao(LineId);
    }
}
