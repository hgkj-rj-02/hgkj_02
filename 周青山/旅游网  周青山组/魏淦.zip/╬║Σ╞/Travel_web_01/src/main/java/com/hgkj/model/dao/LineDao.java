package com.hgkj.model.dao;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LineDao {
    public void addLineDao(Line line);
    public void deleteLineDao(String lineId);
    public void changeLineDao(Line line);
    public Line getLineDao(String lineId);
    public List<Line> allLineDao();
    public List<Line> getLineByLinetypeDao(Linetype linetype);
    public List<Line> getLineNameByLinetypeDao(Linetype linetype);
    public List<Line> getLineNameByTimeDao(Line line);
}
