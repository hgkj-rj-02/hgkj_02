package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.LineDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Linetype;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class LineDaoImpl implements LineDao {
    @Autowired
    private SessionFactory sessionFactory;
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public void addLineDao(Line line) {
        getSession().save(line);
    }

    @Override
    public void deleteLineDao(String lineId) {
        Line line1=getSession().get(Line.class,lineId);
            getSession().delete(line1);
    }

    @Override
    public void changeLineDao(Line line) {
        getSession().update(line);
    }

    @Override
    public Line getLineDao(String lineId) {
        return getSession().get(Line.class,lineId);
    }

    @Override
    public List<Line> allLineDao() {
        Query query=getSession().createQuery("from Line ");
        return query.list();
    }

    @Override
    public List<Line> getLineByLinetypeDao(Linetype linetype) {
        Query query=getSession().createQuery("from Line where linetype.lineTypeId="+linetype.getLineTypeId());
        return query.list();
    }

    @Override
    public List<Line> getLineNameByLinetypeDao(Linetype linetype) {
        Query query=getSession().createQuery("from Line where linetype.lineTypeId="+linetype.getLineTypeId());
        return query.list();
    }

    @Override
    public List<Line> getLineNameByTimeDao(Line line) {
        Query query;
        if ("3".equals(line.getDays())){
            query=getSession().createQuery("from Line where lineId like '100%' and days>="+line.getDays());
        }else {
            query=getSession().createQuery("from Line where lineId like '100%' and days="+line.getDays());
        }
            return query.list();
    }
}
