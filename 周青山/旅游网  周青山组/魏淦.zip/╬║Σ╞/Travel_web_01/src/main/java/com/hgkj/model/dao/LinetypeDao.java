package com.hgkj.model.dao;

import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LinetypeDao {
    public void addLinetypeDao(Linetype linetype);
    public void deleteLinetypeDao(String lineTypeId);
    public void changeLinetypeDao(Linetype linetype);
    public Linetype getLinetypeDao(String lineTypeId);
    public List<Linetype> allLinetypeDao();
}
