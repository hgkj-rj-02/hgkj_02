package com.hgkj.model.dao;

import com.hgkj.model.entity.Customer;
import com.hgkj.model.entity.Orderdetail;

import java.util.List;

public interface OrderdetailDao {
    public void addOrderdetailDao(Orderdetail Orderdetail);
    public void deleteOrderdetailDao(String OrderdetailId);
    public void changeOrderdetailDao(Orderdetail Orderdetail);
    public Orderdetail getOrderdetailDao(String OrderdetailId);
    public List<Orderdetail> allOrderdetailDao();
    public List<Orderdetail> getOrderByCustomerIdDao(Customer customer);
}
