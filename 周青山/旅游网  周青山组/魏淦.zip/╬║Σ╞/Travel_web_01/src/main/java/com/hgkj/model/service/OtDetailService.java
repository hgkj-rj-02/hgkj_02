package com.hgkj.model.service;

import com.hgkj.model.entity.OtDetail;

import java.util.List;

public interface OtDetailService {
    public void addOtDetailService(OtDetail OtDetail);
    public void deleteOtDetailService(int OtDetailId);
    public void changeOtDetailService(OtDetail OtDetail);
    public OtDetail getOtDetailService(int OtDetailId);
    public List<OtDetail> allOtDetailService();
}
