package com.hgkj.model.service.impl;

import com.hgkj.model.dao.CustomerDao;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerDao customerDao;

    public void setCustomerDao(CustomerDao customerDao) {
        this.customerDao = customerDao;
    }

    @Override
    public boolean customerLoginService(Customer customer) {
        return customerDao.customerLoginDao(customer);
    }

    @Override
    public boolean customerAdminLoginService(Customer customer) {
        return customerDao.customerAdminLoginDao(customer);
    }

    @Override
    public void addCustoemrService(Customer customer) {
        customerDao.addCustoemrDao(customer);
    }

    @Override
    public Customer getCustomerByNameService(Customer customer) {
        return customerDao.getCustomerByName(customer);
    }
}
