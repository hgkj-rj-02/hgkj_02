package com.hgkj.model.dao;

import com.hgkj.model.entity.Picture;

import java.util.List;

public interface PictureDao {
    public void addPictureDao(Picture Picture);
    public void deletePictureDao(String PictureId);
    public void changePictureDao(Picture Picture);
    public Picture getPictureDao(String PictureId);
    public List<Picture> allPictureDao();
    public Picture getPictureByLineIdDao(String LineId);
}
