package com.hgkj.controler.action;

import com.hgkj.model.entity.Customer;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Orderdetail;
import com.hgkj.model.entity.Tourist;
import com.hgkj.model.service.OrderdetailService;
import com.hgkj.model.service.OtDetailService;
import com.hgkj.model.service.TouristService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Controller
@Namespace(value = "/")
@ParentPackage(value = "json-default")
public class TouristAction {
    @Autowired
    private TouristService touristService;
    @Autowired
    private OrderdetailService orderdetailService;
    @Autowired
    private OtDetailService otDetailService;
    private List<Tourist> touristList;
    private Timestamp travelDate;

    public List<Tourist> getTouristList() {
        return touristList;
    }

    public void setTouristList(List<Tourist> touristList) {
        this.touristList = touristList;
    }

    public Timestamp getTravelDate() {
        return travelDate;
    }

    public void setTravelDate(Timestamp travelDate) {
        this.travelDate = travelDate;
    }
    public String addTouritsts(){
        Date date=new Date();
        Timestamp timestamp=new Timestamp(date.getTime());
        Customer customer=(Customer) ActionContext.getContext().getSession().get("customer");
        Line line=(Line) ActionContext.getContext().getSession().get("line");
        String orderId=customer.getCustomerId()+line.getLineId()+timestamp;//订单表ID=用户ID+线路ID+下单时间
        ActionContext.getContext().getSession().put("orderIDSettle",orderId);
        Orderdetail orderdetail=new Orderdetail(orderId,customer.getCustomerId(),line.getLineId(),line.getPrice());
    }
}
