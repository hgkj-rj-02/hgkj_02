package com.hgkj.controler.action;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Linetype;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.LineService;
import com.hgkj.model.service.PictureService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace(value = "/")
@ParentPackage(value = "json-default")
public class LineAction {
    @Autowired
    private LineService lineService;
    @Autowired
    private PictureService pictureService;
    private Linetype linetype;
    private Line line;
    private List<Line> lineList;
    private List<Picture> pictureList;
    private Picture picture;

    public List<Picture> getPictureList() {
        return pictureList;
    }

    public void setPictureList(List<Picture> pictureList) {
        this.pictureList = pictureList;
    }

    public Picture getPicture() {
        return picture;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }

    public Linetype getLinetype() {
        return linetype;
    }

    public void setLinetype(Linetype linetype) {
        this.linetype = linetype;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public List<Line> getLineList() {
        return lineList;
    }

    public void setLineList(List<Line> lineList) {
        this.lineList = lineList;
    }
    @Action(value = "getLineByLinetype",results = {@Result(name = "getLineByLinetype",type = "json",params = {"root","lineList"})})
    public String getLinee(){
        lineList=lineService.getLineByLinetypeService(linetype);
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "getLineByLinetype";
    }
    @Action(value = "getLineNameByLinetype",results = {@Result(name = "getLineNameByLinetype",type = "json",params = {"root","lineList"})})
    public String getLineName(){
        lineList=lineService.getLineNameByLinetypeService(linetype);
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "getLineNameByLinetype";
    }
    @Action(value = "getLineNameByTime",results = {@Result(name = "getLineNameByTime",type = "json",params = {"root","lineList"})})
    public String getLineNameByTime(){
        lineList=lineService.getLineNameByTimeService(line);
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "getLineNameByTime";
    }
    @Action(value = "getLineById",results = {@Result(name = "getLineById",type = "redirect",location = "/detail.jsp")})
    public String getLineById(){
        Line line1=lineService.getLineService(line.getLineId());
        picture=pictureService.getPictureByLineIdService(line.getLineId());
        ActionContext.getContext().getSession().put("line1",line1);
        ActionContext.getContext().getSession().put("lineID",line.getLineId());
        ActionContext.getContext().getSession().put("picture",picture);
        return "getLineById";
    }
}
