package com.hgkj.model.service;

import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LinetypeService {
    public void addLinetypeService(Linetype linetype);
    public void deleteLinetypeService(String lineTypeId);
    public void changeLinetypeService(Linetype linetype);
    public Linetype getLinetypeService(String lineTypeId);
    public List<Linetype> allLinetypeService();
}
