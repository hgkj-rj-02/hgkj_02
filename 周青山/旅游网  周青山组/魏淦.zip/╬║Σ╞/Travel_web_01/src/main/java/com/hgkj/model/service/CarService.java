package com.hgkj.model.service;

import com.hgkj.model.entity.Car;

import java.util.List;

public interface CarService {
    public void addCarService(Car Car);
    public void deleteCarService(int CarId);
    public void changeCarService(Car Car);
    public Car getCarService(int CarId);
    public List<Car> allCarService();
    public List<Car> getCarListByCustomerIdService(int customerId);
}
