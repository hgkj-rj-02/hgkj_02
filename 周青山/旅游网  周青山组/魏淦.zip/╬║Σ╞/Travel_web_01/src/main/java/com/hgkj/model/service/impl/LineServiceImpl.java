package com.hgkj.model.service.impl;

import com.hgkj.model.dao.LineDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Linetype;
import com.hgkj.model.service.LineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LineServiceImpl implements LineService {
    @Autowired
    private LineDao lineDao;
    @Override
    public void addLineService(Line line) {
        lineDao.addLineDao(line);
    }

    @Override
    public void deleteLineService(String lineId) {
        lineDao.deleteLineDao(lineId);
    }

    @Override
    public void changeLineService(Line line) {
            lineDao.changeLineDao(line);
    }

    @Override
    public Line getLineService(String lineId) {
        return lineDao.getLineDao(lineId);
    }

    @Override
    public List<Line> allLineService() {
        return lineDao.allLineDao();
    }

    @Override
    public List<Line> getLineByLinetypeService(Linetype linetype) {
        return lineDao.getLineByLinetypeDao(linetype);
    }

    @Override
    public List<Line> getLineNameByLinetypeService(Linetype linetype) {
        return lineDao.getLineNameByLinetypeDao(linetype);
    }

    @Override
    public List<Line> getLineNameByTimeService(Line line) {
        return lineDao.getLineNameByTimeDao(line);
    }


}
