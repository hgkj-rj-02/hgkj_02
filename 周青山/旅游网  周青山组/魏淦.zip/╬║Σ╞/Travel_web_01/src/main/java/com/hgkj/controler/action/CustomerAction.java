package com.hgkj.controler.action;

import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CustomerService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
@Namespace(value = "/")
@ParentPackage(value = "struts-default")
public class CustomerAction {
    @Autowired
    private CustomerService customerService;
    private Customer customer;

    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    @Action(value = "customerLogin",results = {@Result(name = "customerLogin",type = "redirect",location = "/index.jsp"),@Result(name = "customerLoginFalse",type = "redirect",location = "/login.jsp")})
    public String customerLogin(){
        System.out.println(customer.getName());
        Boolean result=customerService.customerLoginService(customer);
        if (result){
            ActionContext.getContext().getSession().put("customerMessage","Welcome!"+customer.getName());
            Customer customer1=customerService.getCustomerByNameService(customer);
            ActionContext.getContext().getSession().put("customer",customer1);
            return "customerLogin";
        }else {
            ActionContext.getContext().getSession().put("customerMessage","请检查用户密码！");
            return "customerLoginFalse";
        }
    }
    public String addCustoemr(){
        customerService.addCustoemrService(customer);
        ActionContext.getContext().getSession().put("customerMessage","Welcome!"+customer.getName());
        return "add";
    }
}
