package com.hgkj.model.service;

import com.hgkj.model.entity.Customer;
import com.hgkj.model.entity.Orderdetail;

import java.util.List;

public interface OrderdetailService {
    public void addOrderdetailService(Orderdetail Orderdetail);
    public void deleteOrderdetailService(String OrderdetailId);
    public void changeOrderdetailService(Orderdetail Orderdetail);
    public Orderdetail getOrderdetailService(String OrderdetailId);
    public List<Orderdetail> allOrderdetailService();
    public List<Orderdetail> getOrderByCustomerIdService(Customer customer);
}
