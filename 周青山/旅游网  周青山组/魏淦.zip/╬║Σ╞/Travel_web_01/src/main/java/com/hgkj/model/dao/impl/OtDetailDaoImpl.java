package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.OtDetailDao;
import com.hgkj.model.entity.Orderdetail;
import com.hgkj.model.entity.OtDetail;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class OtDetailDaoImpl implements OtDetailDao {
    @Autowired
    private SessionFactory sessionFactory;
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public void addOtDetailDao(OtDetail OtDetail) {
            getSession().save(OtDetail);
    }

    @Override
    public void deleteOtDetailDao(int OtDetailId) {
          getSession().delete(getSession().get(OtDetail.class,OtDetailId));
    }

    @Override
    public void changeOtDetailDao(OtDetail OtDetail) {
        getSession().update(OtDetail);
    }

    @Override
    public OtDetail getOtDetailDao(int OtDetailId) {
        return getSession().get(OtDetail.class,OtDetailId);
    }

    @Override
    public List<OtDetail> allOtDetailDao() {
        Query query=getSession().createQuery("from OtDetail ");
        return query.list();
    }
}
