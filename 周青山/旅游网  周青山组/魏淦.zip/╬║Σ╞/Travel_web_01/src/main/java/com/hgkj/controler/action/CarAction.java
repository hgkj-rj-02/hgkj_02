package com.hgkj.controler.action;

import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CarService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Controller
@Namespace(value = "/")
@ParentPackage(value = "json-default")
public class CarAction {
    @Autowired
    private CarService carService;
    private Car car;
    private Customer customer;
    private List<Car> carList;

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<Car> getCarList() {
        return carList;
    }

    public void setCarList(List<Car> carList) {
        this.carList = carList;
    }
    @Action(value = "getCarByCustomerId",results = {@Result(name = "getCarByCustomerId",type = "json",params = {"root","carList"})})
    public String getCarByCustomerId(){
        Customer customer1=(Customer) ActionContext.getContext().getSession().get("customer");
        carList=carService.getCarListByCustomerIdService(Integer.valueOf(customer1.getCustomerId()));
        ActionContext.getContext().getSession().put("carList",carList);
        return "getCarByCustomerId";
    }
    @Action(value = "deleteCarById",results = {@Result(name = "deleteCarById",type = "redirectAction",location = "getCarByCustomerId")})
    public String deleteCarBy(){
        carService.deleteCarService(car.getCarId());
        return "deleteCarById";
    }
    @Action(value = "addCar",results = {@Result(name = "addCar",type = "redirect",location = "/cart.jsp"),@Result(name = "addFalse",type = "redirect",location = "/login.jsp")})
    public String addCar(){
        Customer customer1=(Customer) ActionContext.getContext().getSession().get("customer");
        if (customer1!=null){
            Date date=new Date();
            Timestamp timestamp=new Timestamp(date.getTime());
            car.setTime(timestamp);
            car.setCustomer(customer1);
            System.out.println(car.getLine().getLineId()+car.getCustomer().getCustomerId());
            carService.addCarService(car);
            return "addCar";
        }else {
            return "addFalse";
        }
    }
}
