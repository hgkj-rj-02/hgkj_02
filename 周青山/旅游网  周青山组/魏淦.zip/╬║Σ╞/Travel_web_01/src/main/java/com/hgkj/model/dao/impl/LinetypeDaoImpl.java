package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.LinetypeDao;
import com.hgkj.model.entity.Linetype;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class LinetypeDaoImpl implements LinetypeDao {
    @Autowired
    private SessionFactory sessionFactory;
    public Session getSession(){
        return sessionFactory.getCurrentSession();

    }
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public void addLinetypeDao(Linetype linetype) {
        getSession().save(linetype);
    }

    @Override
    public void deleteLinetypeDao(String lineTypeId) {
        getSession().delete(getSession().get(Linetype.class,lineTypeId));
    }

    @Override
    public void changeLinetypeDao(Linetype linetype) {
            getSession().update(linetype);
    }

    @Override
    public Linetype getLinetypeDao(String lineTypeId) {
        return getSession().get(Linetype.class,lineTypeId);
    }

    @Override
    public List<Linetype> allLinetypeDao() {
        Query query=getSession().createQuery("from Linetype ");
        return query.list();
    }
}
