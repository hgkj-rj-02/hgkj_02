package com.hgkj.model.dao;

import com.hgkj.model.entity.Customer;

public interface CustomerDao {
    //用户登录
    public boolean customerLoginDao(Customer customer);
    //管理员登录
    public boolean customerAdminLoginDao(Customer customer);
    //添加用户
    public void addCustoemrDao(Customer customer);
    //通过用户名称查到用户
    public Customer getCustomerByName(Customer customer);
}
