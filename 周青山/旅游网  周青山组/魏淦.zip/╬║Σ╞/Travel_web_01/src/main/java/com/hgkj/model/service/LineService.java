package com.hgkj.model.service;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LineService {
    public void addLineService(Line line);
    public void deleteLineService(String lineId);
    public void changeLineService(Line line);
    public Line getLineService(String lineId);
    public List<Line> allLineService();
    public List<Line> getLineByLinetypeService(Linetype linetype);
    public List<Line> getLineNameByLinetypeService(Linetype linetype);
    public List<Line> getLineNameByTimeService(Line line);
}
