package com.hgkj.model.service.impl;

import com.hgkj.model.dao.CarDao;
import com.hgkj.model.entity.Car;
import com.hgkj.model.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarServiceImpl implements CarService {
@Autowired
private CarDao carDao;

    @Override
    public void addCarService(Car Car) {
        carDao.addCarDao(Car);
    }

    @Override
    public void deleteCarService(int CarId) {
        carDao.deleteCarDao(CarId);
    }

    @Override
    public void changeCarService(Car Car) {
        carDao.changeCarDao(Car);
    }

    @Override
    public Car getCarService(int CarId) {
        return carDao.getCarDao(CarId);
    }

    @Override
    public List<Car> allCarService() {
        return carDao.allCarDao();
    }

    @Override
    public List<Car> getCarListByCustomerIdService(int customerId) {
        return carDao.getCarListByCustomerIdDao(customerId);
    }
}
