package com.hgkj.model.dao;

import com.hgkj.model.entity.Tourist;

import java.util.List;

public interface TouristDao {
    public void addTouristDao(Tourist Tourist);
    public void deleteTouristDao(String TouristId);
    public void changeTouristDao(Tourist Tourist);
    public Tourist getTouristDao(String TouristId);
    public List<Tourist> allTouristDao();

}
