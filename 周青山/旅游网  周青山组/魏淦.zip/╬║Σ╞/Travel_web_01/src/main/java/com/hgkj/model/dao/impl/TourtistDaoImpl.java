package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.TouristDao;
import com.hgkj.model.entity.Tourist;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class TourtistDaoImpl implements TouristDao {
    @Autowired
    private SessionFactory sessionFactory;
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public void addTouristDao(Tourist Tourist) {
        getSession().save(Tourist);
    }

    @Override
    public void deleteTouristDao(String TouristId) {
        getSession().delete(getSession().get(Tourist.class,TouristId));
    }

    @Override
    public void changeTouristDao(Tourist Tourist) {
        getSession().update(Tourist);
    }

    @Override
    public Tourist getTouristDao(String TouristId) {
        return getSession().get(Tourist.class,TouristId);
    }

    @Override
    public List<Tourist> allTouristDao() {
        Query query=getSession().createQuery("from Tourist ");
        return query.list();
    }
}
