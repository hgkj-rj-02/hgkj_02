package com.hgkj.model.dao;

import com.hgkj.model.entity.Car;

import java.util.List;

public interface CarDao {
    public void addCarDao(Car Car);
    public void deleteCarDao(int CarId);
    public void changeCarDao(Car Car);
    public Car getCarDao(int CarId);
    public List<Car> allCarDao();
    public List<Car> getCarListByCustomerIdDao(int customerId);
}
