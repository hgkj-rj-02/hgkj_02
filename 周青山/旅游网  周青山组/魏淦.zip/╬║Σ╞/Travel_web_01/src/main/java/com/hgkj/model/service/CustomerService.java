package com.hgkj.model.service;

import com.hgkj.model.entity.Customer;

public interface CustomerService {
    //用户登录
    public boolean customerLoginService(Customer customer);
    //管理员登录
    public boolean customerAdminLoginService(Customer customer);
    //添加用户
    public void addCustoemrService(Customer customer);
    //通过用户名称查到用户
    public Customer getCustomerByNameService(Customer customer);
}
