package com.hgkj.model.service;

import com.hgkj.model.entity.Tourist;

import java.util.List;

public interface TouristService {
    public void addTouristService(Tourist Tourist);
    public void deleteTouristService(String TouristId);
    public void changeTouristService(Tourist Tourist);
    public Tourist getTouristService(String TouristId);
    public List<Tourist> allTouristService();

}
