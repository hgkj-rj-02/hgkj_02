package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.OrderdetailDao;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.entity.Orderdetail;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class OrderdetailDaoImpl implements OrderdetailDao {
    @Autowired
    private SessionFactory sessionFactory;
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public void addOrderdetailDao(Orderdetail Orderdetail) {
            getSession().save(Orderdetail);
    }

    @Override
    public void deleteOrderdetailDao(String OrderdetailId) {
        getSession().delete(getSession().get(Orderdetail.class,OrderdetailId));
    }

    @Override
    public void changeOrderdetailDao(Orderdetail Orderdetail) {
        getSession().update(Orderdetail);
    }

    @Override
    public Orderdetail getOrderdetailDao(String OrderdetailId) {
        return getSession().get(Orderdetail.class,OrderdetailId);
    }

    @Override
    public List<Orderdetail> allOrderdetailDao() {
        Query query=getSession().createQuery("from Orderdetail ");
        return query.list();
    }

    @Override
    public List<Orderdetail> getOrderByCustomerIdDao(Customer customer) {
        Query query=getSession().createQuery("from Orderdetail where customer.customerId="+customer.getCustomerId());
        return query.list();
    }
}
