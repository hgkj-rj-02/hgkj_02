package com.hgkj.controler.action;

import com.hgkj.model.entity.Customer;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Orderdetail;
import com.hgkj.model.entity.OtDetail;
import com.hgkj.model.service.LineService;
import com.hgkj.model.service.OrderdetailService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace(value = "/")
@ParentPackage(value = "json-default")
public class OrderAction {
    @Autowired
    private LineService lineService;
    private Orderdetail orderdetail;
    private Line line;
    @Autowired
    private OrderdetailService orderdetailService;

    public Orderdetail getOrderdetail() {
        return orderdetail;
    }

    public void setOrderdetail(Orderdetail orderdetail) {
        this.orderdetail = orderdetail;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }
    @Action(value = "orderGetLineByLinetype",results = {@Result(name = "orderGetLineByLinetype",type = "redirect",location = "order.jsp")})
    public String getLinee(){
        line=lineService.getLineService(line.getLineId());
        ActionContext.getContext().getSession().put("line",line);
        return  "orderGetLineByLinetype";
    }
    @Action(value = "getOrderByCustomerId",results = {@Result(name = "getOrderByCustomerId",type = "redirect",location = "login.jsp"),@Result(name = "getOrderByCustomerId",type = "redirect",location = "orderHistory.jsp")})
    public String getOrderByCustomerId(){
        Customer customer=(Customer) ActionContext.getContext().getSession().get("customer");
        if (customer==null){
            return  "false";
        }
        List<Orderdetail> orderdetailList=orderdetailService.getOrderByCustomerIdService(customer);
        ActionContext.getContext().getSession().put("orderdetail",orderdetailList);
        return "getOrderByCustomerId";
    }
    @Action(value = "getOrderByCustomerId",results = {@Result(name = "getOrderByCustomerId",type = "redirectAction",location = "getOrderByCustomerId.action")})
    public String deleteOrderById(){
        orderdetailService.deleteOrderdetailService(orderdetail.getOdId());
        return "deleteOrderById";
    }
}
