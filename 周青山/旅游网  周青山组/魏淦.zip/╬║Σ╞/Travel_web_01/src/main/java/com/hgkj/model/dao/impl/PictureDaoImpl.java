package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.PictureDao;
import com.hgkj.model.entity.Picture;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class PictureDaoImpl implements PictureDao {
    @Autowired
    private SessionFactory sessionFactory;
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public void addPictureDao(Picture Picture) {
        getSession().save(Picture);
    }

    @Override
    public void deletePictureDao(String PictureId) {
        getSession().delete(getSession().get(Picture.class,PictureId));
    }

    @Override
    public void changePictureDao(Picture Picture) {
        getSession().update(Picture);
    }

    @Override
    public Picture getPictureDao(String PictureId) {
        return getSession().get(Picture.class,PictureId);
    }

    @Override
    public List<Picture> allPictureDao() {
        Query query=getSession().createQuery("from Picture ");
        return query.list();
    }

    @Override
    public Picture getPictureByLineIdDao(String LineId) {
        return (Picture) getSession().createQuery("from Picture where line.lineId='"+LineId+"'").uniqueResult();
    }
}
