package com.hgkj.model.service;

import com.hgkj.model.entity.Picture;

import java.util.List;

public interface PictureService {
    public void addPictureService(Picture Picture);
    public void deletePictureService(String PictureId);
    public void changePictureDaoService(Picture Picture);
    public Picture getPictureService(String PictureId);
    public List<Picture> allPictureService();
    public Picture getPictureByLineIdService(String LineId);
}
