package com.hgkj.model.service.impl;

import com.hgkj.model.dao.TouristDao;
import com.hgkj.model.entity.Tourist;
import com.hgkj.model.service.TouristService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TouristServiceImpl implements TouristService {
    @Autowired
    private TouristDao touristDao;
    @Override
    public void addTouristService(Tourist Tourist) {
        touristDao.addTouristDao(Tourist);
    }

    @Override
    public void deleteTouristService(String TouristId) {
        touristDao.deleteTouristDao(TouristId);
    }

    @Override
    public void changeTouristService(Tourist Tourist) {
        touristDao.changeTouristDao(Tourist);
    }

    @Override
    public Tourist getTouristService(String TouristId) {
        return touristDao.getTouristDao(TouristId);
    }

    @Override
    public List<Tourist> allTouristService() {
        return touristDao.allTouristDao();
    }
}
