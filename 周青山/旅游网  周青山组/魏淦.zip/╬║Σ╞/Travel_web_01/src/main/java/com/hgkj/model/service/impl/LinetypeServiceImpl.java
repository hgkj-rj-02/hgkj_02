package com.hgkj.model.service.impl;


import com.hgkj.model.dao.LinetypeDao;
import com.hgkj.model.entity.Linetype;
import com.hgkj.model.service.LinetypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LinetypeServiceImpl implements LinetypeService {
    @Autowired
    private LinetypeDao linetypeDao;
    @Override
    public void addLinetypeService(Linetype linetype) {
        linetypeDao.addLinetypeDao(linetype);
    }

    @Override
    public void deleteLinetypeService(String lineTypeId) {
        linetypeDao.deleteLinetypeDao(lineTypeId);
    }

    @Override
    public void changeLinetypeService(Linetype linetype) {
        linetypeDao.changeLinetypeDao(linetype);
    }

    @Override
    public Linetype getLinetypeService(String lineTypeId) {
        return linetypeDao.getLinetypeDao(lineTypeId);
    }

    @Override
    public List<Linetype> allLinetypeService() {
        return linetypeDao.allLinetypeDao();
    }
}
