/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50018
Source Host           : localhost:3306
Source Database       : travel_web

Target Server Type    : MYSQL
Target Server Version : 50018
File Encoding         : 65001

Date: 2019-07-09 07:55:22
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `car`
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car` (
  `carID` int(11) NOT NULL auto_increment,
  `customerID` int(11) NOT NULL,
  `lineID` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY  (`carID`),
  KEY `cID` (`customerID`),
  KEY `lID` (`lineID`),
  KEY `FKhbpwxw3p9or49q5aa678er23c` (`lineID`),
  CONSTRAINT `cID` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`),
  CONSTRAINT `FKhbpwxw3p9or49q5aa678er23c` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`),
  CONSTRAINT `lID` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of car
-- ----------------------------
INSERT INTO `car` VALUES ('3', '2', '100102', '2019-06-27 10:28:07');
INSERT INTO `car` VALUES ('4', '1', '100101', '2019-07-04 17:34:00');

-- ----------------------------
-- Table structure for `customer`
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `customerID` int(11) NOT NULL auto_increment,
  `account` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `gender` char(2) NOT NULL,
  `identityID` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `type` int(11) default NULL,
  PRIMARY KEY  (`customerID`),
  UNIQUE KEY `account` (`account`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES ('1', 'admin', 'admin', 'admin', '男', '123123123123123123', '15872609883', '1');
INSERT INTO `customer` VALUES ('2', 'rose', 'admin', '123123', '女', '123123123123123123', '12345678911', null);

-- ----------------------------
-- Table structure for `line`
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line` (
  `lineID` varchar(255) NOT NULL,
  `lineTypeID` varchar(255) NOT NULL,
  `lineName` varchar(255) NOT NULL,
  `days` varchar(255) NOT NULL,
  `vehicle` varchar(255) NOT NULL,
  `introduction` varchar(255) default NULL,
  `reason` varchar(255) default NULL,
  `arrange` varchar(255) default NULL,
  `price` decimal(10,0) NOT NULL,
  `teamBuy` int(11) default NULL,
  `teamBuyPrice` decimal(10,0) default NULL,
  `beginTime` datetime default NULL,
  `endTime` datetime default NULL,
  `onTime` datetime NOT NULL,
  `number` int(11) default NULL,
  PRIMARY KEY  (`lineID`),
  KEY `FKd7h38nar3c77x5uw44ddn6nyf` (`lineTypeID`),
  CONSTRAINT `type` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('1001', '1003', '三亚半自助四日游', '18', '飞机', '好玩儿！！', '到处玩儿', '哈哈哈', '1250', '1', '1150', '2019-06-21 17:56:04', '2019-06-25 17:56:11', '2019-06-21 17:56:45', '66');
INSERT INTO `line` VALUES ('100101', '1001', '凤凰古城', '26', '自驾', null, null, null, '288', null, null, null, null, '2019-06-24 14:31:31', null);
INSERT INTO `line` VALUES ('100102', '1001', '云南大理', '3', '火车', null, null, null, '488', null, null, null, null, '2019-06-24 14:33:15', null);
INSERT INTO `line` VALUES ('100103', '1001', '昆明丽江', '3', '火车', null, null, null, '1288', null, null, null, null, '2019-06-24 14:33:57', null);
INSERT INTO `line` VALUES ('100104', '1001', '西双版纳', '1', '自驾', null, null, null, '1488', null, null, null, null, '2019-06-24 14:46:29', null);
INSERT INTO `line` VALUES ('100105', '1001', '九寨沟', '1', '飞机', null, null, null, '988', null, null, null, null, '2019-06-24 14:47:23', null);
INSERT INTO `line` VALUES ('100201', '1002', '奥地利', '2', '飞机', null, null, null, '1588', null, null, null, null, '2019-06-24 14:47:31', '22');
INSERT INTO `line` VALUES ('100202', '1002', '马尔代夫', '3', '轮船', null, null, null, '1688', null, null, null, null, '2019-06-24 14:49:01', null);
INSERT INTO `line` VALUES ('100203', '1002', '夏威夷', '3 ', '飞机', null, null, null, '1888', null, null, null, null, '2019-06-24 14:49:37', null);
INSERT INTO `line` VALUES ('100204', '1002', '美国', '7', '飞机', null, null, null, '8888', null, null, null, null, '2019-06-24 14:49:45', null);
INSERT INTO `line` VALUES ('100205', '1002', '瑞士', '3', '飞机', null, null, null, '2888', null, null, null, null, '2019-06-24 14:50:18', null);
INSERT INTO `line` VALUES ('100206', '1002', '英国', '2', '飞机', null, null, null, '2888', null, null, null, null, '2019-06-24 14:53:21', null);
INSERT INTO `line` VALUES ('100301', '1003', '北海道', '2', '飞机', null, null, null, '1888', null, null, null, null, '2019-06-24 14:54:45', null);
INSERT INTO `line` VALUES ('100302', '1003', '巴厘岛', '2', '飞机', null, null, null, '1288', null, null, null, null, '2019-06-24 14:55:30', null);
INSERT INTO `line` VALUES ('100303', '1003', '曼谷', '3', '飞机', null, null, null, '1388', null, null, null, null, '2019-06-24 14:56:07', null);
INSERT INTO `line` VALUES ('100304', '1003', '普吉岛', '3', '飞机', null, null, null, '1188', null, null, null, null, '2019-06-24 14:56:14', null);
INSERT INTO `line` VALUES ('100305', '1003', '塞班岛', '2', '飞机', null, null, null, '1188', null, null, null, null, '2019-06-24 14:56:56', null);
INSERT INTO `line` VALUES ('100306', '1003', '香港岛', '2', '飞机', null, null, null, '1088', null, null, null, null, '2019-06-24 14:57:32', null);
INSERT INTO `line` VALUES ('100401', '1004', '张家界', '4', '自驾', null, null, null, '1088', null, null, null, null, '2019-06-24 14:58:48', null);
INSERT INTO `line` VALUES ('100402', '1004', '武当山', '4', '自驾', null, null, null, '488', null, null, null, null, '2019-06-24 14:59:17', null);
INSERT INTO `line` VALUES ('100403', '1004', '黄山', '4', '自驾', null, null, null, '288', null, null, null, null, '2019-06-24 14:59:26', null);
INSERT INTO `line` VALUES ('100404', '1004', '木兰天池', '4', '自驾', null, null, null, '388', null, null, null, null, '2019-06-24 14:59:56', null);
INSERT INTO `line` VALUES ('100405', '1004', '庐山', '1', '自驾', null, null, null, '588', null, null, null, null, '2019-06-24 15:01:16', null);
INSERT INTO `line` VALUES ('100406', '1004', '农耕年华', '1', '自驾', null, null, null, '288', null, null, null, null, '2019-06-24 15:01:53', null);
INSERT INTO `line` VALUES ('135356', '1001', '厦门双飞4日游', '4', '飞机', '住1晚鼓浪屿特色旅馆，1天自由活动', '哈哈', '哈哈', '1664', '1', null, '2019-06-24 08:31:35', '2019-06-27 08:31:41', '2019-06-24 08:31:50', null);
INSERT INTO `line` VALUES ('135398', '1003', '海南双飞五日游', '5', '飞机', '1晚分界洲海景住宿，蜜月专享，恋恋海豚湾 ', null, null, '3517', '1', null, '2019-06-24 08:36:13', '2019-06-28 08:36:18', '2019-06-24 08:36:22', null);
INSERT INTO `line` VALUES ('135399', '1001', '昆大丽双飞6日游', '6', '飞机', null, null, null, '1199', '1', null, '2019-06-24 08:36:32', '2019-06-29 08:36:36', '2019-06-24 08:36:41', null);
INSERT INTO `line` VALUES ('135490', '1004', '武汉欢乐谷1日游', '1', '自驾', '中国文化公园第一连锁品牌，创立于1998年，以“打造世界一流的连锁文化公园”为愿景，旨在为不同的城市，带来同样的欢乐 ', null, null, '170', '1', null, '2019-06-24 08:39:27', '2019-06-25 08:39:31', '2019-06-24 08:39:35', null);
INSERT INTO `line` VALUES ('135497', '1001', '香港迪士尼2日游', '2', '飞机', '香港迪士尼乐园(Disneyland,Hong Kong)的面积只有126.82公顷，是全球面积最小的迪士尼乐园，是世界上的第五个迪士尼乐园。 ', null, null, '55', '1', null, '2019-06-24 08:41:52', '2019-06-26 08:41:55', '2019-06-01 08:42:04', null);
INSERT INTO `line` VALUES ('135498', '1003', '海南三亚5日游', '5', '飞机', null, null, null, '2920', '1', null, '2019-06-24 08:43:40', '2019-06-29 08:43:43', '2019-06-24 08:43:54', null);
INSERT INTO `line` VALUES ('135666', '1002', '夏威夷海滩7日游', '7', '飞机', 'nice!!!!', null, null, '8666', '1', null, '2019-06-24 09:02:21', '2019-06-30 09:02:23', '2019-06-24 09:02:28', null);
INSERT INTO `line` VALUES ('135888', '1002', '马尔代夫亲子3日游', '3', '飞机', '好看漂亮！！！！', null, null, '5666', '1', null, '2019-06-24 08:57:45', '2019-06-27 08:57:47', '2019-06-24 08:57:51', null);

-- ----------------------------
-- Table structure for `linetype`
-- ----------------------------
DROP TABLE IF EXISTS `linetype`;
CREATE TABLE `linetype` (
  `lineTypeID` varchar(255) NOT NULL,
  `typeName` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  `icon` varchar(255) NOT NULL,
  PRIMARY KEY  (`lineTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of linetype
-- ----------------------------
INSERT INTO `linetype` VALUES ('10001', '1日游', '2019-06-24 08:24:56', '1.jpg');
INSERT INTO `linetype` VALUES ('10002', '2日游', '2019-06-24 08:25:14', '2.jpg');
INSERT INTO `linetype` VALUES ('10003', '3日游', '2019-06-24 08:25:42', '3.jpg');
INSERT INTO `linetype` VALUES ('10004', '4日游', '2019-06-24 08:23:30', '.jpg');
INSERT INTO `linetype` VALUES ('10005', '5日游', '2019-06-24 08:23:55', '.jpg');
INSERT INTO `linetype` VALUES ('10006', '6日游', '2019-06-24 08:24:20', '.jpg');
INSERT INTO `linetype` VALUES ('10007', '7日游', '2019-06-24 08:26:09', '.jpg');
INSERT INTO `linetype` VALUES ('1001', '境内游', '2019-06-21 17:46:34', '1.jpg');
INSERT INTO `linetype` VALUES ('1002', '境外游', '2019-06-21 17:47:03', '2.jpg');
INSERT INTO `linetype` VALUES ('1003', '海岛游', '2019-06-21 17:47:27', '.jpg');
INSERT INTO `linetype` VALUES ('1004', '自驾游', '2019-06-21 17:47:44', '.jpg');

-- ----------------------------
-- Table structure for `orderdetail`
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail` (
  `odID` varchar(255) NOT NULL,
  `customerID` int(11) NOT NULL,
  `lineName` varchar(255) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `orderDate` datetime NOT NULL,
  `travelDate` datetime NOT NULL,
  `total` decimal(10,0) NOT NULL,
  `lineID` varchar(255) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY  (`odID`),
  KEY `cusID` (`customerID`),
  KEY `linelID` (`lineID`),
  CONSTRAINT `cusID` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`),
  CONSTRAINT `linelID` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderdetail
-- ----------------------------
INSERT INTO `orderdetail` VALUES ('210012019-06-30 11:31:20.661', '2', '三亚半自助四日游', '2500', '2019-06-30 11:31:20', '2019-11-13 00:00:00', '100', '1001', '1');
INSERT INTO `orderdetail` VALUES ('21003012019-06-30 11:03:10.097', '2', '北海道', '3776', '2019-06-30 11:03:10', '2019-10-01 00:00:00', '100', '100301', '0');
INSERT INTO `orderdetail` VALUES ('21003012019-06-30 11:57:50.916', '2', '北海道', '1888', '2019-06-30 11:57:50', '2019-10-24 00:00:00', '100', '100301', '1');
INSERT INTO `orderdetail` VALUES ('21003012019-06-30 13:11:08.5', '2', '北海道', '1888', '2019-06-30 13:11:08', '2019-12-31 00:00:00', '100', '100301', '1');
INSERT INTO `orderdetail` VALUES ('21003032019-06-30 13:07:26.064', '2', '曼谷', '1388', '2019-06-30 13:07:26', '2019-11-19 00:00:00', '100', '100303', '1');

-- ----------------------------
-- Table structure for `ot_detail`
-- ----------------------------
DROP TABLE IF EXISTS `ot_detail`;
CREATE TABLE `ot_detail` (
  `otID` int(11) NOT NULL auto_increment,
  `odID` varchar(255) NOT NULL,
  `touristID` varchar(255) NOT NULL,
  PRIMARY KEY  (`otID`),
  KEY `odID` (`odID`),
  KEY `touristID` (`touristID`),
  CONSTRAINT `odID` FOREIGN KEY (`odID`) REFERENCES `orderdetail` (`odID`) ON DELETE CASCADE,
  CONSTRAINT `touristID` FOREIGN KEY (`touristID`) REFERENCES `tourist` (`touristID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ot_detail
-- ----------------------------
INSERT INTO `ot_detail` VALUES ('9', '21003012019-06-30 11:03:10.097', '1003012222019-06-30 11:03:10.097');
INSERT INTO `ot_detail` VALUES ('10', '21003012019-06-30 11:03:10.097', '10030166662019-06-30 11:03:10.097');
INSERT INTO `ot_detail` VALUES ('11', '210012019-06-30 11:31:20.661', '1001332019-06-30 11:31:20.661');
INSERT INTO `ot_detail` VALUES ('12', '210012019-06-30 11:31:20.661', '1001444442019-06-30 11:31:20.661');
INSERT INTO `ot_detail` VALUES ('13', '21003012019-06-30 11:57:50.916', '1003012222019-06-30 11:57:50.916');
INSERT INTO `ot_detail` VALUES ('15', '21003032019-06-30 13:07:26.064', '100303222019-06-30 13:07:26.064');
INSERT INTO `ot_detail` VALUES ('16', '21003012019-06-30 13:11:08.5', '1003012222019-06-30 13:11:08.5');

-- ----------------------------
-- Table structure for `picture`
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture` (
  `pictureID` int(11) NOT NULL auto_increment,
  `introduction` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `lineID` varchar(255) NOT NULL,
  PRIMARY KEY  (`pictureID`),
  KEY `FKfawrfkab2v4n4xum1frvd5w3p` (`lineID`),
  CONSTRAINT `FKfawrfkab2v4n4xum1frvd5w3p` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`),
  CONSTRAINT `llID` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of picture
-- ----------------------------
INSERT INTO `picture` VALUES ('1', 'images/jdckb1.jpg', '凤凰古城', '100101');
INSERT INTO `picture` VALUES ('2', 'images/cp.jpg', '街道', '100102');
INSERT INTO `picture` VALUES ('3', 'images/cp1.jpg', '椰树', '100103');
INSERT INTO `picture` VALUES ('4', 'images/cp2.jpg', '海豚', '100104');
INSERT INTO `picture` VALUES ('5', 'images/cp3.jpg', '雪山', '100105');
INSERT INTO `picture` VALUES ('6', 'images/cp4.jpg', '欢乐谷', '135490');
INSERT INTO `picture` VALUES ('7', 'images/cp5.jpg', '迪士尼', '135497');
INSERT INTO `picture` VALUES ('8', 'images/c6.jpg', '海', '135888');

-- ----------------------------
-- Table structure for `tourist`
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist` (
  `touristID` varchar(255) NOT NULL,
  `IDCard` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `realName` varchar(10) NOT NULL,
  PRIMARY KEY  (`touristID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tourist
-- ----------------------------
INSERT INTO `tourist` VALUES ('100111112019-06-30 11:00:52.205', '1111', '23', 'cjl');
INSERT INTO `tourist` VALUES ('10012111112019-06-30 11:00:52.205', '211111', '1111', 'zqs');
INSERT INTO `tourist` VALUES ('1001222019-06-30 13:05:12.474', '22', '22', '对方的');
INSERT INTO `tourist` VALUES ('1001332019-06-30 11:31:20.661', '33', '333', '士大夫');
INSERT INTO `tourist` VALUES ('1001444442019-06-30 11:31:20.661', '44444', '2222', '哈哈哈');
INSERT INTO `tourist` VALUES ('1003012222019-06-30 11:03:10.097', '222', '2323', 'da\'s\'d');
INSERT INTO `tourist` VALUES ('1003012222019-06-30 11:57:50.916', '222', '222', '士大夫');
INSERT INTO `tourist` VALUES ('1003012222019-06-30 13:11:08.5', '222', '222', 'ddd');
INSERT INTO `tourist` VALUES ('10030166662019-06-30 11:03:10.097', '6666', '4545', 'f\'g\'f\'g');
INSERT INTO `tourist` VALUES ('100303222019-06-30 13:07:26.064', '22', '222', 's\'f\'d\'s\'f');
